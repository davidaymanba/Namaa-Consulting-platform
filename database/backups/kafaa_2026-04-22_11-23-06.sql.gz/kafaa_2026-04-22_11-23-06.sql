-- MySQL dump 10.13  Distrib 8.0.45, for Linux (x86_64)
--
-- Host: 127.0.0.1    Database: kafaa
-- ------------------------------------------------------
-- Server version	8.0.45-0ubuntu0.22.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `approval_requests`
--

DROP TABLE IF EXISTS `approval_requests`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `approval_requests` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `module` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `record_id` bigint unsigned NOT NULL,
  `request_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `required_role` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` enum('pending','approved','rejected') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'pending',
  `requested_by` bigint unsigned DEFAULT NULL,
  `approved_by` bigint unsigned DEFAULT NULL,
  `reason` text COLLATE utf8mb4_unicode_ci,
  `approved_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `approval_requests_requested_by_foreign` (`requested_by`),
  KEY `approval_requests_approved_by_foreign` (`approved_by`),
  CONSTRAINT `approval_requests_approved_by_foreign` FOREIGN KEY (`approved_by`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `approval_requests_requested_by_foreign` FOREIGN KEY (`requested_by`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `approval_requests`
--

LOCK TABLES `approval_requests` WRITE;
/*!40000 ALTER TABLE `approval_requests` DISABLE KEYS */;
/*!40000 ALTER TABLE `approval_requests` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `audit_logs`
--

DROP TABLE IF EXISTS `audit_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `audit_logs` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint unsigned DEFAULT NULL,
  `action` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `table_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `record_id` bigint unsigned DEFAULT NULL,
  `old_values` json DEFAULT NULL,
  `new_values` json DEFAULT NULL,
  `module` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ip_address` varchar(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `audit_logs_user_id_foreign` (`user_id`),
  CONSTRAINT `audit_logs_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `audit_logs`
--

LOCK TABLES `audit_logs` WRITE;
/*!40000 ALTER TABLE `audit_logs` DISABLE KEYS */;
INSERT INTO `audit_logs` VALUES (1,1,'create','policies',61,'[]','{\"id\": 61, \"data\": {\"make\": \"test\", \"year\": \"2021\", \"model\": \"test\", \"base_rate\": 0.025, \"engine_cc\": \"1600\", \"driver_age\": \"30\", \"driver_name\": \"david\", \"license_type\": \"خصوصي\", \"market_value\": \"15000\", \"plate_number\": \"564\", \"chassis_number\": \"david\", \"insurance_type\": \"mandatory\", \"installment_mode\": \"monthly\"}, \"type\": \"car\", \"status\": \"active\", \"premium\": \"375.00\", \"end_date\": \"2027-04-22T00:00:00.000000Z\", \"branch_id\": 1, \"broker_id\": \"3\", \"client_id\": \"3\", \"issued_at\": \"2026-04-22T01:40:26.000000Z\", \"issued_by\": 1, \"policy_no\": \"CAR-20260422-6754\", \"created_at\": \"2026-04-22T01:40:26.000000Z\", \"start_date\": \"2026-04-22T00:00:00.000000Z\", \"updated_at\": \"2026-04-22T01:40:26.000000Z\", \"loading_pct\": \"5.00\", \"net_premium\": \"354.38\", \"discount_pct\": \"10.00\"}','policies','127.0.0.1','2026-04-21 23:40:27'),(2,1,'create','claims',21,'[]','{\"id\": 21, \"status\": \"registered\", \"claim_no\": \"CLM-20260422-3632\", \"policy_id\": \"3\", \"created_at\": \"2026-04-22T01:48:50.000000Z\", \"updated_at\": \"2026-04-22T01:48:50.000000Z\", \"description\": \"test\", \"report_date\": \"2026-04-22T00:00:00.000000Z\", \"escalated_at\": null, \"incident_date\": \"2026-04-22T00:00:00.000000Z\", \"claimed_amount\": \"1000.00\", \"estimated_loss\": \"800.00\", \"is_large_claim\": false, \"workflow_notes\": [{\"at\": \"2026-04-22 01:48:50\", \"by\": 1, \"status\": \"registered\"}], \"last_status_update_at\": \"2026-04-22T01:48:50.000000Z\"}','claims','127.0.0.1','2026-04-21 23:48:50'),(3,1,'update','claims',21,'{\"id\": 21, \"status\": \"registered\", \"claim_no\": \"CLM-20260422-3632\", \"policy_id\": 3, \"created_at\": \"2026-04-22T01:48:50.000000Z\", \"updated_at\": \"2026-04-22T01:48:50.000000Z\", \"assigned_to\": null, \"description\": \"test\", \"paid_amount\": \"0.00\", \"report_date\": \"2026-04-22T00:00:00.000000Z\", \"escalated_at\": null, \"incident_date\": \"2026-04-22T00:00:00.000000Z\", \"claimed_amount\": \"1000.00\", \"estimated_loss\": \"800.00\", \"is_large_claim\": false, \"workflow_notes\": [{\"at\": \"2026-04-22 01:48:50\", \"by\": 1, \"status\": \"registered\"}], \"approved_amount\": \"0.00\", \"last_status_update_at\": \"2026-04-22T01:48:50.000000Z\"}','{\"id\": 21, \"status\": \"approved\", \"claim_no\": \"CLM-20260422-3632\", \"policy_id\": 3, \"created_at\": \"2026-04-22T01:48:50.000000Z\", \"updated_at\": \"2026-04-22T01:49:18.000000Z\", \"assigned_to\": null, \"description\": \"test\", \"paid_amount\": \"25.00\", \"report_date\": \"2026-04-22T00:00:00.000000Z\", \"escalated_at\": null, \"incident_date\": \"2026-04-22T00:00:00.000000Z\", \"claimed_amount\": \"1000.00\", \"estimated_loss\": \"800.00\", \"is_large_claim\": false, \"workflow_notes\": [{\"at\": \"2026-04-22 01:48:50\", \"by\": 1, \"status\": \"registered\"}, {\"at\": \"2026-04-22 01:49:18\", \"by\": 1, \"note\": \"test\", \"status\": \"approved\"}], \"approved_amount\": \"100.00\", \"last_status_update_at\": \"2026-04-22T01:49:18.000000Z\"}','claims','127.0.0.1','2026-04-21 23:49:19');
/*!40000 ALTER TABLE `audit_logs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `branches`
--

DROP TABLE IF EXISTS `branches`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `branches` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `code` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `city` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `branches_code_unique` (`code`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `branches`
--

LOCK TABLES `branches` WRITE;
/*!40000 ALTER TABLE `branches` DISABLE KEYS */;
INSERT INTO `branches` VALUES (1,'فرع الرياض','RUH','Riyadh','2026-04-21 23:24:38','2026-04-21 23:24:38'),(2,'فرع جدة','JED','Jeddah','2026-04-21 23:24:38','2026-04-21 23:24:38');
/*!40000 ALTER TABLE `branches` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `brokers`
--

DROP TABLE IF EXISTS `brokers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `brokers` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `code` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `contact` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `commission_rates` json NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `brokers_code_unique` (`code`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `brokers`
--

LOCK TABLES `brokers` WRITE;
/*!40000 ALTER TABLE `brokers` DISABLE KEYS */;
INSERT INTO `brokers` VALUES (1,'وسيط الأمان للتأمين','BRK-101','+966790001111','alaman@broker.sa','{\"car\": 8, \"fire\": 12, \"health\": 10, \"marine\": 14, \"liability\": 9, \"engineering\": 11}','2026-04-21 23:24:39','2026-04-21 23:24:39'),(2,'مركز الوسيط السعودي','BRK-102','+966790002222','jordbroker@broker.sa','{\"car\": 8, \"fire\": 12, \"health\": 10, \"marine\": 14, \"liability\": 9, \"engineering\": 11}','2026-04-21 23:24:39','2026-04-21 23:24:39'),(3,'التميز لخدمات التأمين','BRK-103','+966790003333','tamayoz@broker.sa','{\"car\": 8, \"fire\": 12, \"health\": 10, \"marine\": 14, \"liability\": 9, \"engineering\": 11}','2026-04-21 23:24:39','2026-04-21 23:24:39');
/*!40000 ALTER TABLE `brokers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cache`
--

DROP TABLE IF EXISTS `cache`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cache` (
  `key` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `value` mediumtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `expiration` int NOT NULL,
  PRIMARY KEY (`key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache`
--

LOCK TABLES `cache` WRITE;
/*!40000 ALTER TABLE `cache` DISABLE KEYS */;
/*!40000 ALTER TABLE `cache` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cache_locks`
--

DROP TABLE IF EXISTS `cache_locks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cache_locks` (
  `key` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `owner` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `expiration` int NOT NULL,
  PRIMARY KEY (`key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_locks`
--

LOCK TABLES `cache_locks` WRITE;
/*!40000 ALTER TABLE `cache_locks` DISABLE KEYS */;
/*!40000 ALTER TABLE `cache_locks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `chart_accounts`
--

DROP TABLE IF EXISTS `chart_accounts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `chart_accounts` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `code` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `category` enum('asset','liability','equity','revenue','expense') COLLATE utf8mb4_unicode_ci NOT NULL,
  `currency` varchar(3) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'JOD',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `chart_accounts_code_unique` (`code`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `chart_accounts`
--

LOCK TABLES `chart_accounts` WRITE;
/*!40000 ALTER TABLE `chart_accounts` DISABLE KEYS */;
INSERT INTO `chart_accounts` VALUES (1,'1000','Cash / Bank','asset','SAR','2026-04-21 23:24:43','2026-04-21 23:24:43'),(2,'1100','Accounts Receivable','asset','SAR','2026-04-21 23:24:43','2026-04-21 23:24:43'),(3,'1200','Investments','asset','SAR','2026-04-21 23:24:43','2026-04-21 23:24:43'),(4,'2100','Unearned Premiums','liability','SAR','2026-04-21 23:24:43','2026-04-21 23:24:43'),(5,'2200','Claims Reserve','liability','SAR','2026-04-21 23:24:43','2026-04-21 23:24:43'),(6,'3100','Owner Equity','equity','SAR','2026-04-21 23:24:43','2026-04-21 23:24:43'),(7,'4100','Earned Premiums','revenue','SAR','2026-04-21 23:24:43','2026-04-21 23:24:43'),(8,'4200','Commission Income','revenue','SAR','2026-04-21 23:24:44','2026-04-21 23:24:44'),(9,'5100','Claims Expense','expense','SAR','2026-04-21 23:24:44','2026-04-21 23:24:44'),(10,'5200','Commission Paid','expense','SAR','2026-04-21 23:24:44','2026-04-21 23:24:44'),(11,'5300','Operations Expense','expense','SAR','2026-04-21 23:24:44','2026-04-21 23:24:44');
/*!40000 ALTER TABLE `chart_accounts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `claim_documents`
--

DROP TABLE IF EXISTS `claim_documents`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `claim_documents` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `claim_id` bigint unsigned NOT NULL,
  `file_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `file_path` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `mime_type` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `size` bigint unsigned NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `claim_documents_claim_id_foreign` (`claim_id`),
  CONSTRAINT `claim_documents_claim_id_foreign` FOREIGN KEY (`claim_id`) REFERENCES `claims` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `claim_documents`
--

LOCK TABLES `claim_documents` WRITE;
/*!40000 ALTER TABLE `claim_documents` DISABLE KEYS */;
/*!40000 ALTER TABLE `claim_documents` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `claims`
--

DROP TABLE IF EXISTS `claims`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `claims` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `claim_no` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `policy_id` bigint unsigned NOT NULL,
  `assigned_to` bigint unsigned DEFAULT NULL,
  `status` enum('registered','under_investigation','surveyor_assigned','report_received','approved','rejected','paid') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'registered',
  `incident_date` date NOT NULL,
  `report_date` date NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `claimed_amount` decimal(14,2) NOT NULL DEFAULT '0.00',
  `estimated_loss` decimal(14,2) NOT NULL DEFAULT '0.00',
  `approved_amount` decimal(14,2) NOT NULL DEFAULT '0.00',
  `paid_amount` decimal(14,2) NOT NULL DEFAULT '0.00',
  `is_large_claim` tinyint(1) NOT NULL DEFAULT '0',
  `escalated_at` timestamp NULL DEFAULT NULL,
  `last_status_update_at` timestamp NULL DEFAULT NULL,
  `workflow_notes` json DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `claims_claim_no_unique` (`claim_no`),
  KEY `claims_policy_id_foreign` (`policy_id`),
  KEY `claims_assigned_to_foreign` (`assigned_to`),
  CONSTRAINT `claims_assigned_to_foreign` FOREIGN KEY (`assigned_to`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `claims_policy_id_foreign` FOREIGN KEY (`policy_id`) REFERENCES `policies` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `claims`
--

LOCK TABLES `claims` WRITE;
/*!40000 ALTER TABLE `claims` DISABLE KEYS */;
INSERT INTO `claims` VALUES (1,'CLM-000001',1,NULL,'approved','2026-07-08','2026-01-12','مطالبة تجريبية ناتجة عن حادث مؤمّن عليه',8593.00,7304.05,6015.10,4726.15,0,NULL,'2026-03-23 23:24:45','[{\"at\": \"2026-04-12 01:24:45\", \"by\": 2, \"status\": \"registered\"}]','2026-04-21 23:24:45','2026-04-21 23:24:45'),(2,'CLM-000004',4,NULL,'registered','2026-07-03','2026-04-12','مطالبة تجريبية ناتجة عن حادث مؤمّن عليه',3564.00,3029.40,2494.80,1960.20,0,NULL,'2026-04-02 23:24:47','[{\"at\": \"2026-04-12 01:24:47\", \"by\": 2, \"status\": \"registered\"}]','2026-04-21 23:24:47','2026-04-21 23:24:47'),(3,'CLM-000007',7,NULL,'report_received','2025-06-12','2025-07-02','مطالبة تجريبية ناتجة عن حادث مؤمّن عليه',5605.00,4764.25,3923.50,3082.75,0,NULL,'2026-04-12 23:24:49','[{\"at\": \"2026-04-12 01:24:49\", \"by\": 2, \"status\": \"registered\"}]','2026-04-21 23:24:49','2026-04-21 23:24:49'),(4,'CLM-000010',10,NULL,'report_received','2026-07-07','2026-08-27','مطالبة تجريبية ناتجة عن حادث مؤمّن عليه',803.00,682.55,562.10,441.65,0,NULL,'2026-04-19 23:24:52','[{\"at\": \"2026-04-12 01:24:52\", \"by\": 2, \"status\": \"registered\"}]','2026-04-21 23:24:52','2026-04-21 23:24:52'),(5,'CLM-000013',13,NULL,'under_investigation','2025-10-27','2025-09-23','مطالبة تجريبية ناتجة عن حادث مؤمّن عليه',4431.00,3766.35,3101.70,2437.05,0,NULL,'2026-04-05 23:24:54','[{\"at\": \"2026-04-12 01:24:54\", \"by\": 2, \"status\": \"registered\"}]','2026-04-21 23:24:54','2026-04-21 23:24:54'),(6,'CLM-000016',16,NULL,'report_received','2025-10-03','2025-12-02','مطالبة تجريبية ناتجة عن حادث مؤمّن عليه',8662.00,7362.70,6063.40,4764.10,0,NULL,'2026-04-20 23:24:56','[{\"at\": \"2026-04-12 01:24:56\", \"by\": 2, \"status\": \"registered\"}]','2026-04-21 23:24:56','2026-04-21 23:24:56'),(7,'CLM-000019',19,NULL,'registered','2026-03-24','2026-05-05','مطالبة تجريبية ناتجة عن حادث مؤمّن عليه',6318.00,5370.30,4422.60,3474.90,0,NULL,'2026-03-15 23:24:59','[{\"at\": \"2026-04-12 01:24:59\", \"by\": 2, \"status\": \"registered\"}]','2026-04-21 23:24:59','2026-04-21 23:24:59'),(8,'CLM-000022',22,NULL,'paid','2026-05-21','2026-05-15','مطالبة تجريبية ناتجة عن حادث مؤمّن عليه',10735.00,9124.75,7514.50,5904.25,1,'2026-04-13 23:25:01','2026-04-16 23:25:01','[{\"at\": \"2026-04-12 01:25:01\", \"by\": 2, \"status\": \"registered\"}]','2026-04-21 23:25:01','2026-04-21 23:25:01'),(9,'CLM-000025',25,NULL,'registered','2026-08-27','2026-09-25','مطالبة تجريبية ناتجة عن حادث مؤمّن عليه',4576.00,3889.60,3203.20,2516.80,0,NULL,'2026-04-15 23:25:04','[{\"at\": \"2026-04-12 01:25:04\", \"by\": 2, \"status\": \"registered\"}]','2026-04-21 23:25:04','2026-04-21 23:25:04'),(10,'CLM-000028',28,NULL,'report_received','2026-03-10','2026-06-24','مطالبة تجريبية ناتجة عن حادث مؤمّن عليه',2537.00,2156.45,1775.90,1395.35,0,NULL,'2026-04-11 23:25:06','[{\"at\": \"2026-04-12 01:25:06\", \"by\": 2, \"status\": \"registered\"}]','2026-04-21 23:25:06','2026-04-21 23:25:06'),(11,'CLM-000031',31,NULL,'under_investigation','2026-01-12','2026-03-22','مطالبة تجريبية ناتجة عن حادث مؤمّن عليه',7003.00,5952.55,4902.10,3851.65,0,NULL,'2026-04-09 23:25:08','[{\"at\": \"2026-04-12 01:25:08\", \"by\": 2, \"status\": \"registered\"}]','2026-04-21 23:25:08','2026-04-21 23:25:08'),(12,'CLM-000034',34,NULL,'registered','2025-06-24','2025-12-27','مطالبة تجريبية ناتجة عن حادث مؤمّن عليه',7696.00,6541.60,5387.20,4232.80,0,NULL,'2026-04-02 23:25:11','[{\"at\": \"2026-04-12 01:25:11\", \"by\": 2, \"status\": \"registered\"}]','2026-04-21 23:25:11','2026-04-21 23:25:11'),(13,'CLM-000037',37,NULL,'report_received','2025-12-02','2026-02-28','مطالبة تجريبية ناتجة عن حادث مؤمّن عليه',4437.00,3771.45,3105.90,2440.35,0,NULL,'2026-03-31 23:25:13','[{\"at\": \"2026-04-12 01:25:13\", \"by\": 2, \"status\": \"registered\"}]','2026-04-21 23:25:13','2026-04-21 23:25:13'),(14,'CLM-000040',40,NULL,'registered','2025-11-25','2025-09-29','مطالبة تجريبية ناتجة عن حادث مؤمّن عليه',9771.00,8305.35,6839.70,5374.05,0,NULL,'2026-03-15 23:25:15','[{\"at\": \"2026-04-12 01:25:15\", \"by\": 2, \"status\": \"registered\"}]','2026-04-21 23:25:15','2026-04-21 23:25:15'),(15,'CLM-000043',43,NULL,'paid','2026-03-19','2026-01-28','مطالبة تجريبية ناتجة عن حادث مؤمّن عليه',3888.00,3304.80,2721.60,2138.40,0,NULL,'2026-04-07 23:25:17','[{\"at\": \"2026-04-12 01:25:17\", \"by\": 2, \"status\": \"registered\"}]','2026-04-21 23:25:17','2026-04-21 23:25:17'),(16,'CLM-000046',46,NULL,'approved','2026-04-19','2026-09-25','مطالبة تجريبية ناتجة عن حادث مؤمّن عليه',6714.00,5706.90,4699.80,3692.70,0,NULL,'2026-04-09 23:25:20','[{\"at\": \"2026-04-12 01:25:20\", \"by\": 2, \"status\": \"registered\"}]','2026-04-21 23:25:20','2026-04-21 23:25:20'),(17,'CLM-000049',49,NULL,'approved','2026-02-10','2026-05-21','مطالبة تجريبية ناتجة عن حادث مؤمّن عليه',8838.00,7512.30,6186.60,4860.90,0,NULL,'2026-03-16 23:25:22','[{\"at\": \"2026-04-12 01:25:22\", \"by\": 2, \"status\": \"registered\"}]','2026-04-21 23:25:22','2026-04-21 23:25:22'),(18,'CLM-000052',52,NULL,'under_investigation','2026-02-14','2025-12-18','مطالبة تجريبية ناتجة عن حادث مؤمّن عليه',11816.00,10043.60,8271.20,6498.80,1,'2026-04-16 23:25:25','2026-03-12 23:25:25','[{\"at\": \"2026-04-12 01:25:25\", \"by\": 2, \"status\": \"registered\"}]','2026-04-21 23:25:25','2026-04-21 23:25:25'),(19,'CLM-000055',55,NULL,'report_received','2026-04-17','2026-02-10','مطالبة تجريبية ناتجة عن حادث مؤمّن عليه',7532.00,6402.20,5272.40,4142.60,0,NULL,'2026-04-19 23:25:27','[{\"at\": \"2026-04-12 01:25:27\", \"by\": 2, \"status\": \"registered\"}]','2026-04-21 23:25:27','2026-04-21 23:25:27'),(20,'CLM-000058',58,NULL,'report_received','2026-09-09','2026-07-05','مطالبة تجريبية ناتجة عن حادث مؤمّن عليه',4168.00,3542.80,2917.60,2292.40,0,NULL,'2026-03-31 23:25:29','[{\"at\": \"2026-04-12 01:25:29\", \"by\": 2, \"status\": \"registered\"}]','2026-04-21 23:25:29','2026-04-21 23:25:29'),(21,'CLM-20260422-3632',3,NULL,'approved','2026-04-22','2026-04-22','test',1000.00,800.00,100.00,25.00,0,NULL,'2026-04-21 23:49:18','[{\"at\": \"2026-04-22 01:48:50\", \"by\": 1, \"status\": \"registered\"}, {\"at\": \"2026-04-22 01:49:18\", \"by\": 1, \"note\": \"test\", \"status\": \"approved\"}]','2026-04-21 23:48:50','2026-04-21 23:49:18');
/*!40000 ALTER TABLE `claims` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `clients`
--

DROP TABLE IF EXISTS `clients`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `clients` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` enum('individual','company') COLLATE utf8mb4_unicode_ci NOT NULL,
  `national_id` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `contact` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `address` text COLLATE utf8mb4_unicode_ci,
  `meta` json DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `clients_national_id_unique` (`national_id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `clients`
--

LOCK TABLES `clients` WRITE;
/*!40000 ALTER TABLE `clients` DISABLE KEYS */;
INSERT INTO `clients` VALUES (1,'شركة النخبة للتجارة','company','20001234567','+962796001001',NULL,'عمّان - الشميساني','{\"country\": \"Jordan\"}','2026-04-21 23:24:39','2026-04-21 23:24:39'),(2,'محمد خالد العياصرة','individual','9876543210','+962795002002',NULL,'إربد - الحي الشرقي','{\"country\": \"Jordan\"}','2026-04-21 23:24:39','2026-04-21 23:24:39'),(3,'شركة الميناء للشحن','company','20007654321','+962794003003',NULL,'العقبة - المنطقة الصناعية','{\"country\": \"Jordan\"}','2026-04-21 23:24:39','2026-04-21 23:24:39'),(4,'ليان سامر الخطيب','individual','2233445566','+962797004004',NULL,'عمّان - تلاع العلي','{\"country\": \"Jordan\"}','2026-04-21 23:24:39','2026-04-21 23:24:39'),(5,'مقاولات البناء الحديث','company','20006543219','+962799005005',NULL,'الزرقاء - الوسط التجاري','{\"country\": \"Jordan\"}','2026-04-21 23:24:39','2026-04-21 23:24:39'),(6,'أحمد يونس الشوابكة','individual','1122334455','+962796006006',NULL,'مادبا - وسط البلد','{\"country\": \"Jordan\"}','2026-04-21 23:24:40','2026-04-21 23:24:40'),(7,'مصنع البتراء للصناعات','company','20002221111','+962790007007',NULL,'الكرك - المنطقة الصناعية','{\"country\": \"Jordan\"}','2026-04-21 23:24:40','2026-04-21 23:24:40'),(8,'ديما نزار الزعبي','individual','5544332211','+962793008008',NULL,'جرش - الحي الجنوبي','{\"country\": \"Jordan\"}','2026-04-21 23:24:40','2026-04-21 23:24:40');
/*!40000 ALTER TABLE `clients` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `failed_jobs`
--

DROP TABLE IF EXISTS `failed_jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `failed_jobs` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `uuid` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `connection` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `failed_jobs`
--

LOCK TABLES `failed_jobs` WRITE;
/*!40000 ALTER TABLE `failed_jobs` DISABLE KEYS */;
/*!40000 ALTER TABLE `failed_jobs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `job_batches`
--

DROP TABLE IF EXISTS `job_batches`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `job_batches` (
  `id` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `total_jobs` int NOT NULL,
  `pending_jobs` int NOT NULL,
  `failed_jobs` int NOT NULL,
  `failed_job_ids` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `options` mediumtext COLLATE utf8mb4_unicode_ci,
  `cancelled_at` int DEFAULT NULL,
  `created_at` int NOT NULL,
  `finished_at` int DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `job_batches`
--

LOCK TABLES `job_batches` WRITE;
/*!40000 ALTER TABLE `job_batches` DISABLE KEYS */;
/*!40000 ALTER TABLE `job_batches` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `jobs`
--

DROP TABLE IF EXISTS `jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `jobs` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `queue` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `attempts` tinyint unsigned NOT NULL,
  `reserved_at` int unsigned DEFAULT NULL,
  `available_at` int unsigned NOT NULL,
  `created_at` int unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `jobs_queue_index` (`queue`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `jobs`
--

LOCK TABLES `jobs` WRITE;
/*!40000 ALTER TABLE `jobs` DISABLE KEYS */;
/*!40000 ALTER TABLE `jobs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `journal_entries`
--

DROP TABLE IF EXISTS `journal_entries`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `journal_entries` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `date` date NOT NULL,
  `debit_account` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `credit_account` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `amount` decimal(14,2) NOT NULL,
  `currency` varchar(3) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'JOD',
  `reference` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `entry_type` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta` json DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=62 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `journal_entries`
--

LOCK TABLES `journal_entries` WRITE;
/*!40000 ALTER TABLE `journal_entries` DISABLE KEYS */;
INSERT INTO `journal_entries` VALUES (1,'2025-12-14','1100-Accounts Receivable','4100-Earned Premiums',1662.00,'SAR','POL-000001','policy_issuance',NULL,'2026-04-21 23:24:45','2026-04-21 23:24:45'),(2,'2025-07-20','1100-Accounts Receivable','4100-Earned Premiums',6480.00,'SAR','POL-000002','policy_issuance',NULL,'2026-04-21 23:24:45','2026-04-21 23:24:45'),(3,'2025-10-14','1100-Accounts Receivable','4100-Earned Premiums',6057.00,'SAR','POL-000003','policy_issuance',NULL,'2026-04-21 23:24:46','2026-04-21 23:24:46'),(4,'2026-01-04','1100-Accounts Receivable','4100-Earned Premiums',2781.00,'SAR','POL-000004','policy_issuance',NULL,'2026-04-21 23:24:47','2026-04-21 23:24:47'),(5,'2025-08-27','1100-Accounts Receivable','4100-Earned Premiums',2936.00,'SAR','POL-000005','policy_issuance',NULL,'2026-04-21 23:24:48','2026-04-21 23:24:48'),(6,'2025-10-02','1100-Accounts Receivable','4100-Earned Premiums',2529.00,'SAR','POL-000006','policy_issuance',NULL,'2026-04-21 23:24:48','2026-04-21 23:24:48'),(7,'2025-05-16','1100-Accounts Receivable','4100-Earned Premiums',685.00,'SAR','POL-000007','policy_issuance',NULL,'2026-04-21 23:24:49','2026-04-21 23:24:49'),(8,'2025-08-01','1100-Accounts Receivable','4100-Earned Premiums',4315.00,'SAR','POL-000008','policy_issuance',NULL,'2026-04-21 23:24:50','2026-04-21 23:24:50'),(9,'2025-07-26','1100-Accounts Receivable','4100-Earned Premiums',234.00,'SAR','POL-000009','policy_issuance',NULL,'2026-04-21 23:24:51','2026-04-21 23:24:51'),(10,'2026-04-19','1100-Accounts Receivable','4100-Earned Premiums',1593.00,'SAR','POL-000010','policy_issuance',NULL,'2026-04-21 23:24:52','2026-04-21 23:24:52'),(11,'2025-09-29','1100-Accounts Receivable','4100-Earned Premiums',1222.00,'SAR','POL-000011','policy_issuance',NULL,'2026-04-21 23:24:52','2026-04-21 23:24:52'),(12,'2025-05-01','1100-Accounts Receivable','4100-Earned Premiums',3502.00,'SAR','POL-000012','policy_issuance',NULL,'2026-04-21 23:24:53','2026-04-21 23:24:53'),(13,'2025-06-05','1100-Accounts Receivable','4100-Earned Premiums',6472.00,'SAR','POL-000013','policy_issuance',NULL,'2026-04-21 23:24:54','2026-04-21 23:24:54'),(14,'2026-02-08','1100-Accounts Receivable','4100-Earned Premiums',391.00,'SAR','POL-000014','policy_issuance',NULL,'2026-04-21 23:24:55','2026-04-21 23:24:55'),(15,'2025-06-27','1100-Accounts Receivable','4100-Earned Premiums',4158.00,'SAR','POL-000015','policy_issuance',NULL,'2026-04-21 23:24:55','2026-04-21 23:24:55'),(16,'2025-08-10','1100-Accounts Receivable','4100-Earned Premiums',200.00,'SAR','POL-000016','policy_issuance',NULL,'2026-04-21 23:24:56','2026-04-21 23:24:56'),(17,'2026-03-02','1100-Accounts Receivable','4100-Earned Premiums',230.00,'SAR','POL-000017','policy_issuance',NULL,'2026-04-21 23:24:57','2026-04-21 23:24:57'),(18,'2025-06-09','1100-Accounts Receivable','4100-Earned Premiums',836.00,'SAR','POL-000018','policy_issuance',NULL,'2026-04-21 23:24:58','2026-04-21 23:24:58'),(19,'2026-02-06','1100-Accounts Receivable','4100-Earned Premiums',4412.00,'SAR','POL-000019','policy_issuance',NULL,'2026-04-21 23:24:59','2026-04-21 23:24:59'),(20,'2025-05-27','1100-Accounts Receivable','4100-Earned Premiums',1861.00,'SAR','POL-000020','policy_issuance',NULL,'2026-04-21 23:24:59','2026-04-21 23:24:59'),(21,'2026-04-16','1100-Accounts Receivable','4100-Earned Premiums',648.00,'SAR','POL-000021','policy_issuance',NULL,'2026-04-21 23:25:00','2026-04-21 23:25:00'),(22,'2025-12-08','1100-Accounts Receivable','4100-Earned Premiums',4211.00,'SAR','POL-000022','policy_issuance',NULL,'2026-04-21 23:25:01','2026-04-21 23:25:01'),(23,'2025-10-12','1100-Accounts Receivable','4100-Earned Premiums',3065.00,'SAR','POL-000023','policy_issuance',NULL,'2026-04-21 23:25:02','2026-04-21 23:25:02'),(24,'2026-03-21','1100-Accounts Receivable','4100-Earned Premiums',2286.00,'SAR','POL-000024','policy_issuance',NULL,'2026-04-21 23:25:03','2026-04-21 23:25:03'),(25,'2026-02-24','1100-Accounts Receivable','4100-Earned Premiums',2902.00,'SAR','POL-000025','policy_issuance',NULL,'2026-04-21 23:25:04','2026-04-21 23:25:04'),(26,'2025-06-08','1100-Accounts Receivable','4100-Earned Premiums',3240.00,'SAR','POL-000026','policy_issuance',NULL,'2026-04-21 23:25:05','2026-04-21 23:25:05'),(27,'2026-03-21','1100-Accounts Receivable','4100-Earned Premiums',3852.00,'SAR','POL-000027','policy_issuance',NULL,'2026-04-21 23:25:05','2026-04-21 23:25:05'),(28,'2026-01-06','1100-Accounts Receivable','4100-Earned Premiums',5252.00,'SAR','POL-000028','policy_issuance',NULL,'2026-04-21 23:25:06','2026-04-21 23:25:06'),(29,'2025-12-08','1100-Accounts Receivable','4100-Earned Premiums',4091.00,'SAR','POL-000029','policy_issuance',NULL,'2026-04-21 23:25:07','2026-04-21 23:25:07'),(30,'2026-04-19','1100-Accounts Receivable','4100-Earned Premiums',5456.00,'SAR','POL-000030','policy_issuance',NULL,'2026-04-21 23:25:08','2026-04-21 23:25:08'),(31,'2025-08-17','1100-Accounts Receivable','4100-Earned Premiums',1347.00,'SAR','POL-000031','policy_issuance',NULL,'2026-04-21 23:25:08','2026-04-21 23:25:08'),(32,'2025-12-17','1100-Accounts Receivable','4100-Earned Premiums',2069.00,'SAR','POL-000032','policy_issuance',NULL,'2026-04-21 23:25:09','2026-04-21 23:25:09'),(33,'2025-12-06','1100-Accounts Receivable','4100-Earned Premiums',6021.00,'SAR','POL-000033','policy_issuance',NULL,'2026-04-21 23:25:10','2026-04-21 23:25:10'),(34,'2025-05-26','1100-Accounts Receivable','4100-Earned Premiums',4317.00,'SAR','POL-000034','policy_issuance',NULL,'2026-04-21 23:25:11','2026-04-21 23:25:11'),(35,'2026-03-01','1100-Accounts Receivable','4100-Earned Premiums',972.00,'SAR','POL-000035','policy_issuance',NULL,'2026-04-21 23:25:11','2026-04-21 23:25:11'),(36,'2025-09-01','1100-Accounts Receivable','4100-Earned Premiums',3750.00,'SAR','POL-000036','policy_issuance',NULL,'2026-04-21 23:25:12','2026-04-21 23:25:12'),(37,'2025-10-09','1100-Accounts Receivable','4100-Earned Premiums',5460.00,'SAR','POL-000037','policy_issuance',NULL,'2026-04-21 23:25:13','2026-04-21 23:25:13'),(38,'2026-03-16','1100-Accounts Receivable','4100-Earned Premiums',2013.00,'SAR','POL-000038','policy_issuance',NULL,'2026-04-21 23:25:14','2026-04-21 23:25:14'),(39,'2025-12-07','1100-Accounts Receivable','4100-Earned Premiums',2302.00,'SAR','POL-000039','policy_issuance',NULL,'2026-04-21 23:25:14','2026-04-21 23:25:14'),(40,'2025-05-03','1100-Accounts Receivable','4100-Earned Premiums',3681.00,'SAR','POL-000040','policy_issuance',NULL,'2026-04-21 23:25:15','2026-04-21 23:25:15'),(41,'2025-07-29','1100-Accounts Receivable','4100-Earned Premiums',338.00,'SAR','POL-000041','policy_issuance',NULL,'2026-04-21 23:25:16','2026-04-21 23:25:16'),(42,'2026-04-08','1100-Accounts Receivable','4100-Earned Premiums',2919.00,'SAR','POL-000042','policy_issuance',NULL,'2026-04-21 23:25:17','2026-04-21 23:25:17'),(43,'2025-10-01','1100-Accounts Receivable','4100-Earned Premiums',1026.00,'SAR','POL-000043','policy_issuance',NULL,'2026-04-21 23:25:17','2026-04-21 23:25:17'),(44,'2026-04-20','1100-Accounts Receivable','4100-Earned Premiums',3911.00,'SAR','POL-000044','policy_issuance',NULL,'2026-04-21 23:25:18','2026-04-21 23:25:18'),(45,'2026-04-07','1100-Accounts Receivable','4100-Earned Premiums',3765.00,'SAR','POL-000045','policy_issuance',NULL,'2026-04-21 23:25:19','2026-04-21 23:25:19'),(46,'2026-03-03','1100-Accounts Receivable','4100-Earned Premiums',4716.00,'SAR','POL-000046','policy_issuance',NULL,'2026-04-21 23:25:19','2026-04-21 23:25:19'),(47,'2025-05-07','1100-Accounts Receivable','4100-Earned Premiums',3312.00,'SAR','POL-000047','policy_issuance',NULL,'2026-04-21 23:25:20','2026-04-21 23:25:20'),(48,'2025-10-07','1100-Accounts Receivable','4100-Earned Premiums',5021.00,'SAR','POL-000048','policy_issuance',NULL,'2026-04-21 23:25:22','2026-04-21 23:25:22'),(49,'2025-11-03','1100-Accounts Receivable','4100-Earned Premiums',821.00,'SAR','POL-000049','policy_issuance',NULL,'2026-04-21 23:25:22','2026-04-21 23:25:22'),(50,'2026-01-17','1100-Accounts Receivable','4100-Earned Premiums',4570.00,'SAR','POL-000050','policy_issuance',NULL,'2026-04-21 23:25:23','2026-04-21 23:25:23'),(51,'2025-07-04','1100-Accounts Receivable','4100-Earned Premiums',6250.00,'SAR','POL-000051','policy_issuance',NULL,'2026-04-21 23:25:24','2026-04-21 23:25:24'),(52,'2025-09-13','1100-Accounts Receivable','4100-Earned Premiums',489.00,'SAR','POL-000052','policy_issuance',NULL,'2026-04-21 23:25:24','2026-04-21 23:25:24'),(53,'2025-10-04','1100-Accounts Receivable','4100-Earned Premiums',5237.00,'SAR','POL-000053','policy_issuance',NULL,'2026-04-21 23:25:25','2026-04-21 23:25:25'),(54,'2025-08-08','1100-Accounts Receivable','4100-Earned Premiums',5701.00,'SAR','POL-000054','policy_issuance',NULL,'2026-04-21 23:25:26','2026-04-21 23:25:26'),(55,'2025-11-07','1100-Accounts Receivable','4100-Earned Premiums',3134.00,'SAR','POL-000055','policy_issuance',NULL,'2026-04-21 23:25:27','2026-04-21 23:25:27'),(56,'2026-03-15','1100-Accounts Receivable','4100-Earned Premiums',1366.00,'SAR','POL-000056','policy_issuance',NULL,'2026-04-21 23:25:28','2026-04-21 23:25:28'),(57,'2026-01-02','1100-Accounts Receivable','4100-Earned Premiums',4059.00,'SAR','POL-000057','policy_issuance',NULL,'2026-04-21 23:25:28','2026-04-21 23:25:28'),(58,'2026-02-17','1100-Accounts Receivable','4100-Earned Premiums',307.00,'SAR','POL-000058','policy_issuance',NULL,'2026-04-21 23:25:29','2026-04-21 23:25:29'),(59,'2026-02-05','1100-Accounts Receivable','4100-Earned Premiums',2736.00,'SAR','POL-000059','policy_issuance',NULL,'2026-04-21 23:25:30','2026-04-21 23:25:30'),(60,'2025-05-05','1100-Accounts Receivable','4100-Earned Premiums',1828.00,'SAR','POL-000060','policy_issuance',NULL,'2026-04-21 23:25:30','2026-04-21 23:25:30'),(61,'2026-04-22','1100-Accounts Receivable','4100-Earned Premiums',354.38,'SAR','CAR-20260422-6754','policy_issuance',NULL,'2026-04-21 23:40:27','2026-04-21 23:40:27');
/*!40000 ALTER TABLE `journal_entries` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `migrations`
--

DROP TABLE IF EXISTS `migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `migrations` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `migrations`
--

LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
INSERT INTO `migrations` VALUES (1,'0001_01_01_000000_create_users_table',1),(2,'0001_01_01_000001_create_cache_table',1),(3,'0001_01_01_000002_create_jobs_table',1),(4,'2026_04_22_000100_create_insurance_core_tables',1);
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `password_reset_tokens`
--

DROP TABLE IF EXISTS `password_reset_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `password_reset_tokens` (
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `password_reset_tokens`
--

LOCK TABLES `password_reset_tokens` WRITE;
/*!40000 ALTER TABLE `password_reset_tokens` DISABLE KEYS */;
/*!40000 ALTER TABLE `password_reset_tokens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `policies`
--

DROP TABLE IF EXISTS `policies`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `policies` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `policy_no` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `client_id` bigint unsigned NOT NULL,
  `broker_id` bigint unsigned DEFAULT NULL,
  `branch_id` bigint unsigned DEFAULT NULL,
  `issued_by` bigint unsigned DEFAULT NULL,
  `type` enum('health','car','fire','marine','engineering','liability') COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` enum('draft','active','renewed','cancelled','expired') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'draft',
  `premium` decimal(14,2) NOT NULL DEFAULT '0.00',
  `discount_pct` decimal(5,2) NOT NULL DEFAULT '0.00',
  `loading_pct` decimal(5,2) NOT NULL DEFAULT '0.00',
  `net_premium` decimal(14,2) NOT NULL DEFAULT '0.00',
  `start_date` date NOT NULL,
  `end_date` date NOT NULL,
  `issued_at` timestamp NULL DEFAULT NULL,
  `data` json DEFAULT NULL,
  `archived_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `policies_policy_no_unique` (`policy_no`),
  KEY `policies_client_id_foreign` (`client_id`),
  KEY `policies_broker_id_foreign` (`broker_id`),
  KEY `policies_branch_id_foreign` (`branch_id`),
  KEY `policies_issued_by_foreign` (`issued_by`),
  CONSTRAINT `policies_branch_id_foreign` FOREIGN KEY (`branch_id`) REFERENCES `branches` (`id`) ON DELETE SET NULL,
  CONSTRAINT `policies_broker_id_foreign` FOREIGN KEY (`broker_id`) REFERENCES `brokers` (`id`) ON DELETE SET NULL,
  CONSTRAINT `policies_client_id_foreign` FOREIGN KEY (`client_id`) REFERENCES `clients` (`id`) ON DELETE CASCADE,
  CONSTRAINT `policies_issued_by_foreign` FOREIGN KEY (`issued_by`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=62 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `policies`
--

LOCK TABLES `policies` WRITE;
/*!40000 ALTER TABLE `policies` DISABLE KEYS */;
INSERT INTO `policies` VALUES (1,'POL-000001',1,1,1,1,'health','active',1662.00,1.00,8.00,1662.00,'2025-12-14','2026-12-14','2025-12-13 23:24:44','{\"generic\": true}',NULL,'2026-04-21 23:24:44','2026-04-21 23:24:44'),(2,'POL-000002',2,2,2,1,'car','active',6480.00,12.00,3.00,6480.00,'2025-07-20','2026-07-20','2025-07-19 22:24:45','{\"make\": \"Toyota\", \"year\": 2019, \"model\": \"Elantra\", \"base_rate\": 0.025, \"engine_cc\": 1897, \"driver_age\": 22, \"driver_name\": \"سائق 2\", \"license_type\": \"خصوصي\", \"market_value\": 30949, \"plate_number\": \"JO-12463\", \"chassis_number\": \"CH832244\", \"insurance_type\": \"mandatory\", \"installment_mode\": \"quarterly\"}',NULL,'2026-04-21 23:24:45','2026-04-21 23:24:45'),(3,'POL-000003',3,3,1,1,'fire','active',6057.00,10.00,5.00,6057.00,'2025-10-14','2026-10-14','2025-10-13 22:24:45','{\"generic\": true}',NULL,'2026-04-21 23:24:45','2026-04-21 23:24:45'),(4,'POL-000004',4,1,2,1,'marine','renewed',2781.00,6.00,9.00,2781.00,'2026-01-04','2027-01-04','2026-01-03 23:24:46','{\"generic\": true}',NULL,'2026-04-21 23:24:46','2026-04-21 23:24:46'),(5,'POL-000005',5,2,1,1,'engineering','expired',2936.00,3.00,6.00,2936.00,'2025-08-27','2026-08-27','2025-08-26 22:24:47','{\"generic\": true}',NULL,'2026-04-21 23:24:47','2026-04-21 23:24:47'),(6,'POL-000006',6,3,2,1,'liability','active',2529.00,6.00,6.00,2529.00,'2025-10-02','2026-10-02','2025-10-01 22:24:48','{\"generic\": true}',NULL,'2026-04-21 23:24:48','2026-04-21 23:24:48'),(7,'POL-000007',7,1,1,1,'health','active',685.00,7.00,5.00,685.00,'2025-05-16','2026-05-16','2025-05-15 22:24:49','{\"generic\": true}',NULL,'2026-04-21 23:24:49','2026-04-21 23:24:49'),(8,'POL-000008',8,2,2,1,'car','active',4315.00,3.00,0.00,4315.00,'2025-08-01','2026-08-01','2025-07-31 22:24:49','{\"make\": \"Hyundai\", \"year\": 2023, \"model\": \"Sunny\", \"base_rate\": 0.025, \"engine_cc\": 2974, \"driver_age\": 23, \"driver_name\": \"سائق 8\", \"license_type\": \"خصوصي\", \"market_value\": 16851, \"plate_number\": \"JO-55711\", \"chassis_number\": \"CH405745\", \"insurance_type\": \"mandatory\", \"installment_mode\": \"monthly\"}',NULL,'2026-04-21 23:24:49','2026-04-21 23:24:49'),(9,'POL-000009',1,3,1,1,'fire','renewed',234.00,5.00,5.00,234.00,'2025-07-26','2026-07-26','2025-07-25 22:24:50','{\"generic\": true}',NULL,'2026-04-21 23:24:50','2026-04-21 23:24:50'),(10,'POL-000010',2,1,2,1,'marine','expired',1593.00,7.00,9.00,1593.00,'2026-04-19','2027-04-19','2026-04-18 23:24:51','{\"generic\": true}',NULL,'2026-04-21 23:24:51','2026-04-21 23:24:51'),(11,'POL-000011',3,2,1,1,'engineering','active',1222.00,10.00,0.00,1222.00,'2025-09-29','2026-09-29','2025-09-28 22:24:52','{\"generic\": true}',NULL,'2026-04-21 23:24:52','2026-04-21 23:24:52'),(12,'POL-000012',4,3,2,1,'liability','active',3502.00,11.00,7.00,3502.00,'2025-05-01','2026-05-01','2025-04-30 22:24:53','{\"generic\": true}',NULL,'2026-04-21 23:24:53','2026-04-21 23:24:53'),(13,'POL-000013',5,1,1,1,'health','active',6472.00,0.00,8.00,6472.00,'2025-06-05','2026-06-05','2025-06-04 22:24:53','{\"generic\": true}',NULL,'2026-04-21 23:24:53','2026-04-21 23:24:53'),(14,'POL-000014',6,2,2,1,'car','renewed',391.00,1.00,10.00,391.00,'2026-02-08','2027-02-08','2026-02-07 23:24:54','{\"make\": \"Kia\", \"year\": 2020, \"model\": \"Sportage\", \"base_rate\": 0.025, \"engine_cc\": 2145, \"driver_age\": 39, \"driver_name\": \"سائق 14\", \"license_type\": \"خصوصي\", \"market_value\": 12635, \"plate_number\": \"JO-77046\", \"chassis_number\": \"CH475243\", \"insurance_type\": \"mandatory\", \"installment_mode\": \"monthly\"}',NULL,'2026-04-21 23:24:54','2026-04-21 23:24:54'),(15,'POL-000015',7,3,1,1,'fire','expired',4158.00,1.00,1.00,4158.00,'2025-06-27','2026-06-27','2025-06-26 22:24:55','{\"generic\": true}',NULL,'2026-04-21 23:24:55','2026-04-21 23:24:55'),(16,'POL-000016',8,1,2,1,'marine','active',200.00,6.00,7.00,200.00,'2025-08-10','2026-08-10','2025-08-09 22:24:55','{\"generic\": true}',NULL,'2026-04-21 23:24:55','2026-04-21 23:24:55'),(17,'POL-000017',1,2,1,1,'engineering','active',230.00,5.00,6.00,230.00,'2026-03-02','2027-03-02','2026-03-01 23:24:56','{\"generic\": true}',NULL,'2026-04-21 23:24:56','2026-04-21 23:24:56'),(18,'POL-000018',2,3,2,1,'liability','active',836.00,1.00,6.00,836.00,'2025-06-09','2026-06-09','2025-06-08 22:24:57','{\"generic\": true}',NULL,'2026-04-21 23:24:57','2026-04-21 23:24:57'),(19,'POL-000019',3,1,1,1,'health','renewed',4412.00,5.00,0.00,4412.00,'2026-02-06','2027-02-06','2026-02-05 23:24:58','{\"generic\": true}',NULL,'2026-04-21 23:24:58','2026-04-21 23:24:58'),(20,'POL-000020',4,2,2,1,'car','expired',1861.00,1.00,1.00,1861.00,'2025-05-27','2026-05-27','2025-05-26 22:24:59','{\"make\": \"Kia\", \"year\": 2021, \"model\": \"Sunny\", \"base_rate\": 0.025, \"engine_cc\": 2487, \"driver_age\": 35, \"driver_name\": \"سائق 20\", \"license_type\": \"خصوصي\", \"market_value\": 23015, \"plate_number\": \"JO-15203\", \"chassis_number\": \"CH504455\", \"insurance_type\": \"comprehensive\", \"installment_mode\": \"monthly\"}',NULL,'2026-04-21 23:24:59','2026-04-21 23:24:59'),(21,'POL-000021',5,3,1,1,'fire','active',648.00,10.00,7.00,648.00,'2026-04-16','2027-04-16','2026-04-15 23:25:00','{\"generic\": true}',NULL,'2026-04-21 23:25:00','2026-04-21 23:25:00'),(22,'POL-000022',6,1,2,1,'marine','active',4211.00,10.00,9.00,4211.00,'2025-12-08','2026-12-08','2025-12-07 23:25:00','{\"generic\": true}',NULL,'2026-04-21 23:25:00','2026-04-21 23:25:00'),(23,'POL-000023',7,2,1,1,'engineering','active',3065.00,4.00,8.00,3065.00,'2025-10-12','2026-10-12','2025-10-11 22:25:01','{\"generic\": true}',NULL,'2026-04-21 23:25:01','2026-04-21 23:25:01'),(24,'POL-000024',8,3,2,1,'liability','renewed',2286.00,8.00,8.00,2286.00,'2026-03-21','2027-03-21','2026-03-20 23:25:02','{\"generic\": true}',NULL,'2026-04-21 23:25:02','2026-04-21 23:25:02'),(25,'POL-000025',1,1,1,1,'health','expired',2902.00,10.00,10.00,2902.00,'2026-02-24','2027-02-24','2026-02-23 23:25:03','{\"generic\": true}',NULL,'2026-04-21 23:25:03','2026-04-21 23:25:03'),(26,'POL-000026',2,2,2,1,'car','active',3240.00,9.00,10.00,3240.00,'2025-06-08','2026-06-08','2025-06-07 22:25:04','{\"make\": \"Toyota\", \"year\": 2025, \"model\": \"Elantra\", \"base_rate\": 0.025, \"engine_cc\": 2515, \"driver_age\": 34, \"driver_name\": \"سائق 26\", \"license_type\": \"خصوصي\", \"market_value\": 21529, \"plate_number\": \"JO-62912\", \"chassis_number\": \"CH724133\", \"insurance_type\": \"mandatory\", \"installment_mode\": \"monthly\"}',NULL,'2026-04-21 23:25:04','2026-04-21 23:25:04'),(27,'POL-000027',3,3,1,1,'fire','active',3852.00,5.00,8.00,3852.00,'2026-03-21','2027-03-21','2026-03-20 23:25:05','{\"generic\": true}',NULL,'2026-04-21 23:25:05','2026-04-21 23:25:05'),(28,'POL-000028',4,1,2,1,'marine','active',5252.00,7.00,1.00,5252.00,'2026-01-06','2027-01-06','2026-01-05 23:25:05','{\"generic\": true}',NULL,'2026-04-21 23:25:05','2026-04-21 23:25:05'),(29,'POL-000029',5,2,1,1,'engineering','renewed',4091.00,11.00,1.00,4091.00,'2025-12-08','2026-12-08','2025-12-07 23:25:06','{\"generic\": true}',NULL,'2026-04-21 23:25:06','2026-04-21 23:25:06'),(30,'POL-000030',6,3,2,1,'liability','expired',5456.00,8.00,9.00,5456.00,'2026-04-19','2027-04-19','2026-04-18 23:25:07','{\"generic\": true}',NULL,'2026-04-21 23:25:07','2026-04-21 23:25:07'),(31,'POL-000031',7,1,1,1,'health','active',1347.00,9.00,0.00,1347.00,'2025-08-17','2026-08-17','2025-08-16 22:25:08','{\"generic\": true}',NULL,'2026-04-21 23:25:08','2026-04-21 23:25:08'),(32,'POL-000032',8,2,2,1,'car','active',2069.00,9.00,7.00,2069.00,'2025-12-17','2026-12-17','2025-12-16 23:25:09','{\"make\": \"Kia\", \"year\": 2017, \"model\": \"Sportage\", \"base_rate\": 0.025, \"engine_cc\": 2411, \"driver_age\": 44, \"driver_name\": \"سائق 32\", \"license_type\": \"خصوصي\", \"market_value\": 23605, \"plate_number\": \"JO-48348\", \"chassis_number\": \"CH971460\", \"insurance_type\": \"comprehensive\", \"installment_mode\": \"annual\"}',NULL,'2026-04-21 23:25:09','2026-04-21 23:25:09'),(33,'POL-000033',1,3,1,1,'fire','active',6021.00,11.00,2.00,6021.00,'2025-12-06','2026-12-06','2025-12-05 23:25:09','{\"generic\": true}',NULL,'2026-04-21 23:25:09','2026-04-21 23:25:09'),(34,'POL-000034',2,1,2,1,'marine','renewed',4317.00,7.00,3.00,4317.00,'2025-05-26','2026-05-26','2025-05-25 22:25:10','{\"generic\": true}',NULL,'2026-04-21 23:25:10','2026-04-21 23:25:10'),(35,'POL-000035',3,2,1,1,'engineering','expired',972.00,6.00,8.00,972.00,'2026-03-01','2027-03-01','2026-02-28 23:25:11','{\"generic\": true}',NULL,'2026-04-21 23:25:11','2026-04-21 23:25:11'),(36,'POL-000036',4,3,2,1,'liability','active',3750.00,6.00,0.00,3750.00,'2025-09-01','2026-09-01','2025-08-31 22:25:12','{\"generic\": true}',NULL,'2026-04-21 23:25:12','2026-04-21 23:25:12'),(37,'POL-000037',5,1,1,1,'health','active',5460.00,11.00,10.00,5460.00,'2025-10-09','2026-10-09','2025-10-08 22:25:12','{\"generic\": true}',NULL,'2026-04-21 23:25:12','2026-04-21 23:25:12'),(38,'POL-000038',6,2,2,1,'car','active',2013.00,2.00,8.00,2013.00,'2026-03-16','2027-03-16','2026-03-15 23:25:13','{\"make\": \"Hyundai\", \"year\": 2025, \"model\": \"Elantra\", \"base_rate\": 0.025, \"engine_cc\": 2109, \"driver_age\": 38, \"driver_name\": \"سائق 38\", \"license_type\": \"خصوصي\", \"market_value\": 14210, \"plate_number\": \"JO-22869\", \"chassis_number\": \"CH214072\", \"insurance_type\": \"mandatory\", \"installment_mode\": \"annual\"}',NULL,'2026-04-21 23:25:13','2026-04-21 23:25:13'),(39,'POL-000039',7,3,1,1,'fire','renewed',2302.00,6.00,1.00,2302.00,'2025-12-07','2026-12-07','2025-12-06 23:25:14','{\"generic\": true}',NULL,'2026-04-21 23:25:14','2026-04-21 23:25:14'),(40,'POL-000040',8,1,2,1,'marine','expired',3681.00,0.00,2.00,3681.00,'2025-05-03','2026-05-03','2025-05-02 22:25:14','{\"generic\": true}',NULL,'2026-04-21 23:25:14','2026-04-21 23:25:14'),(41,'POL-000041',1,2,1,1,'engineering','active',338.00,9.00,9.00,338.00,'2025-07-29','2026-07-29','2025-07-28 22:25:15','{\"generic\": true}',NULL,'2026-04-21 23:25:15','2026-04-21 23:25:15'),(42,'POL-000042',2,3,2,1,'liability','active',2919.00,2.00,5.00,2919.00,'2026-04-08','2027-04-08','2026-04-07 23:25:16','{\"generic\": true}',NULL,'2026-04-21 23:25:16','2026-04-21 23:25:16'),(43,'POL-000043',3,1,1,1,'health','active',1026.00,9.00,6.00,1026.00,'2025-10-01','2026-10-01','2025-09-30 22:25:17','{\"generic\": true}',NULL,'2026-04-21 23:25:17','2026-04-21 23:25:17'),(44,'POL-000044',4,2,2,1,'car','renewed',3911.00,3.00,7.00,3911.00,'2026-04-20','2027-04-20','2026-04-19 23:25:17','{\"make\": \"Kia\", \"year\": 2017, \"model\": \"Elantra\", \"base_rate\": 0.025, \"engine_cc\": 2697, \"driver_age\": 42, \"driver_name\": \"سائق 44\", \"license_type\": \"خصوصي\", \"market_value\": 21573, \"plate_number\": \"JO-12401\", \"chassis_number\": \"CH329599\", \"insurance_type\": \"mandatory\", \"installment_mode\": \"monthly\"}',NULL,'2026-04-21 23:25:17','2026-04-21 23:25:17'),(45,'POL-000045',5,3,1,1,'fire','expired',3765.00,10.00,10.00,3765.00,'2026-04-07','2027-04-07','2026-04-06 23:25:18','{\"generic\": true}',NULL,'2026-04-21 23:25:18','2026-04-21 23:25:18'),(46,'POL-000046',6,1,2,1,'marine','active',4716.00,9.00,10.00,4716.00,'2026-03-03','2027-03-03','2026-03-02 23:25:19','{\"generic\": true}',NULL,'2026-04-21 23:25:19','2026-04-21 23:25:19'),(47,'POL-000047',7,2,1,1,'engineering','active',3312.00,1.00,7.00,3312.00,'2025-05-07','2026-05-07','2025-05-06 22:25:20','{\"generic\": true}',NULL,'2026-04-21 23:25:20','2026-04-21 23:25:20'),(48,'POL-000048',8,3,2,1,'liability','active',5021.00,11.00,4.00,5021.00,'2025-10-07','2026-10-07','2025-10-06 22:25:20','{\"generic\": true}',NULL,'2026-04-21 23:25:20','2026-04-21 23:25:20'),(49,'POL-000049',1,1,1,1,'health','renewed',821.00,10.00,5.00,821.00,'2025-11-03','2026-11-03','2025-11-02 23:25:22','{\"generic\": true}',NULL,'2026-04-21 23:25:22','2026-04-21 23:25:22'),(50,'POL-000050',2,2,2,1,'car','expired',4570.00,9.00,2.00,4570.00,'2026-01-17','2027-01-17','2026-01-16 23:25:23','{\"make\": \"Nissan\", \"year\": 2019, \"model\": \"Sportage\", \"base_rate\": 0.025, \"engine_cc\": 1956, \"driver_age\": 35, \"driver_name\": \"سائق 50\", \"license_type\": \"خصوصي\", \"market_value\": 32011, \"plate_number\": \"JO-31865\", \"chassis_number\": \"CH243282\", \"insurance_type\": \"comprehensive\", \"installment_mode\": \"annual\"}',NULL,'2026-04-21 23:25:23','2026-04-21 23:25:23'),(51,'POL-000051',3,3,1,1,'fire','active',6250.00,8.00,1.00,6250.00,'2025-07-04','2026-07-04','2025-07-03 22:25:23','{\"generic\": true}',NULL,'2026-04-21 23:25:23','2026-04-21 23:25:23'),(52,'POL-000052',4,1,2,1,'marine','active',489.00,8.00,6.00,489.00,'2025-09-13','2026-09-13','2025-09-12 22:25:24','{\"generic\": true}',NULL,'2026-04-21 23:25:24','2026-04-21 23:25:24'),(53,'POL-000053',5,2,1,1,'engineering','active',5237.00,3.00,6.00,5237.00,'2025-10-04','2026-10-04','2025-10-03 22:25:25','{\"generic\": true}',NULL,'2026-04-21 23:25:25','2026-04-21 23:25:25'),(54,'POL-000054',6,3,2,1,'liability','renewed',5701.00,3.00,9.00,5701.00,'2025-08-08','2026-08-08','2025-08-07 22:25:25','{\"generic\": true}',NULL,'2026-04-21 23:25:25','2026-04-21 23:25:25'),(55,'POL-000055',7,1,1,1,'health','expired',3134.00,8.00,0.00,3134.00,'2025-11-07','2026-11-07','2025-11-06 23:25:26','{\"generic\": true}',NULL,'2026-04-21 23:25:26','2026-04-21 23:25:26'),(56,'POL-000056',8,2,2,1,'car','active',1366.00,10.00,6.00,1366.00,'2026-03-15','2027-03-15','2026-03-14 23:25:27','{\"make\": \"Kia\", \"year\": 2023, \"model\": \"Corolla\", \"base_rate\": 0.025, \"engine_cc\": 2298, \"driver_age\": 54, \"driver_name\": \"سائق 56\", \"license_type\": \"خصوصي\", \"market_value\": 10852, \"plate_number\": \"JO-65151\", \"chassis_number\": \"CH780752\", \"insurance_type\": \"comprehensive\", \"installment_mode\": \"annual\"}',NULL,'2026-04-21 23:25:27','2026-04-21 23:25:27'),(57,'POL-000057',1,3,1,1,'fire','active',4059.00,0.00,0.00,4059.00,'2026-01-02','2027-01-02','2026-01-01 23:25:28','{\"generic\": true}',NULL,'2026-04-21 23:25:28','2026-04-21 23:25:28'),(58,'POL-000058',2,1,2,1,'marine','active',307.00,0.00,10.00,307.00,'2026-02-17','2027-02-17','2026-02-16 23:25:28','{\"generic\": true}',NULL,'2026-04-21 23:25:28','2026-04-21 23:25:28'),(59,'POL-000059',3,2,1,1,'engineering','renewed',2736.00,8.00,10.00,2736.00,'2026-02-05','2027-02-05','2026-02-04 23:25:29','{\"generic\": true}',NULL,'2026-04-21 23:25:29','2026-04-21 23:25:29'),(60,'POL-000060',4,3,2,1,'liability','expired',1828.00,12.00,10.00,1828.00,'2025-05-05','2026-05-05','2025-05-04 22:25:30','{\"generic\": true}',NULL,'2026-04-21 23:25:30','2026-04-21 23:25:30'),(61,'CAR-20260422-6754',3,3,1,1,'car','active',375.00,10.00,5.00,354.38,'2026-04-22','2027-04-22','2026-04-21 23:40:26','{\"make\": \"test\", \"year\": \"2021\", \"model\": \"test\", \"base_rate\": 0.025, \"engine_cc\": \"1600\", \"driver_age\": \"30\", \"driver_name\": \"david\", \"license_type\": \"خصوصي\", \"market_value\": \"15000\", \"plate_number\": \"564\", \"chassis_number\": \"david\", \"insurance_type\": \"mandatory\", \"installment_mode\": \"monthly\"}',NULL,'2026-04-21 23:40:26','2026-04-21 23:40:26');
/*!40000 ALTER TABLE `policies` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `policy_installments`
--

DROP TABLE IF EXISTS `policy_installments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `policy_installments` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `policy_id` bigint unsigned NOT NULL,
  `sequence` tinyint unsigned NOT NULL,
  `due_date` date NOT NULL,
  `amount` decimal(14,2) NOT NULL,
  `status` enum('pending','paid','overdue') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'pending',
  `paid_at` date DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `policy_installments_policy_id_foreign` (`policy_id`),
  CONSTRAINT `policy_installments_policy_id_foreign` FOREIGN KEY (`policy_id`) REFERENCES `policies` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=253 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `policy_installments`
--

LOCK TABLES `policy_installments` WRITE;
/*!40000 ALTER TABLE `policy_installments` DISABLE KEYS */;
INSERT INTO `policy_installments` VALUES (1,1,1,'2025-12-14',415.50,'paid','2026-02-27','2026-04-21 23:24:44','2026-04-21 23:24:44'),(2,1,2,'2026-03-14',415.50,'paid','2026-04-18','2026-04-21 23:24:44','2026-04-21 23:24:44'),(3,1,3,'2026-06-14',415.50,'pending',NULL,'2026-04-21 23:24:44','2026-04-21 23:24:44'),(4,1,4,'2026-09-14',415.50,'pending',NULL,'2026-04-21 23:24:44','2026-04-21 23:24:44'),(5,2,1,'2025-07-20',1620.00,'paid','2026-03-31','2026-04-21 23:24:45','2026-04-21 23:24:45'),(6,2,2,'2025-10-20',1620.00,'paid','2026-04-12','2026-04-21 23:24:45','2026-04-21 23:24:45'),(7,2,3,'2026-01-20',1620.00,'pending',NULL,'2026-04-21 23:24:45','2026-04-21 23:24:45'),(8,2,4,'2026-04-20',1620.00,'pending',NULL,'2026-04-21 23:24:45','2026-04-21 23:24:45'),(9,3,1,'2025-10-14',1514.25,'paid','2026-04-12','2026-04-21 23:24:46','2026-04-21 23:24:46'),(10,3,2,'2026-01-14',1514.25,'paid','2026-03-07','2026-04-21 23:24:46','2026-04-21 23:24:46'),(11,3,3,'2026-04-14',1514.25,'pending',NULL,'2026-04-21 23:24:46','2026-04-21 23:24:46'),(12,3,4,'2026-07-14',1514.25,'pending',NULL,'2026-04-21 23:24:46','2026-04-21 23:24:46'),(13,4,1,'2026-01-04',695.25,'paid','2026-03-06','2026-04-21 23:24:46','2026-04-21 23:24:46'),(14,4,2,'2026-04-04',695.25,'paid','2026-04-01','2026-04-21 23:24:47','2026-04-21 23:24:47'),(15,4,3,'2026-07-04',695.25,'pending',NULL,'2026-04-21 23:24:47','2026-04-21 23:24:47'),(16,4,4,'2026-10-04',695.25,'pending',NULL,'2026-04-21 23:24:47','2026-04-21 23:24:47'),(17,5,1,'2025-08-27',734.00,'paid','2026-03-17','2026-04-21 23:24:47','2026-04-21 23:24:47'),(18,5,2,'2025-11-27',734.00,'paid','2026-04-17','2026-04-21 23:24:47','2026-04-21 23:24:47'),(19,5,3,'2026-02-27',734.00,'pending',NULL,'2026-04-21 23:24:47','2026-04-21 23:24:47'),(20,5,4,'2026-05-27',734.00,'pending',NULL,'2026-04-21 23:24:48','2026-04-21 23:24:48'),(21,6,1,'2025-10-02',632.25,'paid','2026-04-12','2026-04-21 23:24:48','2026-04-21 23:24:48'),(22,6,2,'2026-01-02',632.25,'paid','2026-03-18','2026-04-21 23:24:48','2026-04-21 23:24:48'),(23,6,3,'2026-04-02',632.25,'pending',NULL,'2026-04-21 23:24:48','2026-04-21 23:24:48'),(24,6,4,'2026-07-02',632.25,'pending',NULL,'2026-04-21 23:24:48','2026-04-21 23:24:48'),(25,7,1,'2025-05-16',171.25,'paid','2026-03-11','2026-04-21 23:24:49','2026-04-21 23:24:49'),(26,7,2,'2025-08-16',171.25,'paid','2026-04-15','2026-04-21 23:24:49','2026-04-21 23:24:49'),(27,7,3,'2025-11-16',171.25,'pending',NULL,'2026-04-21 23:24:49','2026-04-21 23:24:49'),(28,7,4,'2026-02-16',171.25,'pending',NULL,'2026-04-21 23:24:49','2026-04-21 23:24:49'),(29,8,1,'2025-08-01',1078.75,'paid','2026-03-17','2026-04-21 23:24:50','2026-04-21 23:24:50'),(30,8,2,'2025-11-01',1078.75,'paid','2026-04-17','2026-04-21 23:24:50','2026-04-21 23:24:50'),(31,8,3,'2026-02-01',1078.75,'pending',NULL,'2026-04-21 23:24:50','2026-04-21 23:24:50'),(32,8,4,'2026-05-01',1078.75,'pending',NULL,'2026-04-21 23:24:50','2026-04-21 23:24:50'),(33,9,1,'2025-07-26',58.50,'paid','2026-03-30','2026-04-21 23:24:50','2026-04-21 23:24:50'),(34,9,2,'2025-10-26',58.50,'paid','2026-04-05','2026-04-21 23:24:51','2026-04-21 23:24:51'),(35,9,3,'2026-01-26',58.50,'pending',NULL,'2026-04-21 23:24:51','2026-04-21 23:24:51'),(36,9,4,'2026-04-26',58.50,'pending',NULL,'2026-04-21 23:24:51','2026-04-21 23:24:51'),(37,10,1,'2026-04-19',398.25,'paid','2026-03-04','2026-04-21 23:24:51','2026-04-21 23:24:51'),(38,10,2,'2026-07-19',398.25,'paid','2026-03-07','2026-04-21 23:24:51','2026-04-21 23:24:51'),(39,10,3,'2026-10-19',398.25,'pending',NULL,'2026-04-21 23:24:51','2026-04-21 23:24:51'),(40,10,4,'2027-01-19',398.25,'pending',NULL,'2026-04-21 23:24:52','2026-04-21 23:24:52'),(41,11,1,'2025-09-29',305.50,'paid','2026-04-13','2026-04-21 23:24:52','2026-04-21 23:24:52'),(42,11,2,'2025-12-29',305.50,'paid','2026-03-15','2026-04-21 23:24:52','2026-04-21 23:24:52'),(43,11,3,'2026-03-29',305.50,'pending',NULL,'2026-04-21 23:24:52','2026-04-21 23:24:52'),(44,11,4,'2026-06-29',305.50,'pending',NULL,'2026-04-21 23:24:52','2026-04-21 23:24:52'),(45,12,1,'2025-05-01',875.50,'paid','2026-03-26','2026-04-21 23:24:53','2026-04-21 23:24:53'),(46,12,2,'2025-08-01',875.50,'paid','2026-04-17','2026-04-21 23:24:53','2026-04-21 23:24:53'),(47,12,3,'2025-11-01',875.50,'pending',NULL,'2026-04-21 23:24:53','2026-04-21 23:24:53'),(48,12,4,'2026-02-01',875.50,'pending',NULL,'2026-04-21 23:24:53','2026-04-21 23:24:53'),(49,13,1,'2025-06-05',1618.00,'paid','2026-02-27','2026-04-21 23:24:53','2026-04-21 23:24:53'),(50,13,2,'2025-09-05',1618.00,'paid','2026-03-26','2026-04-21 23:24:53','2026-04-21 23:24:53'),(51,13,3,'2025-12-05',1618.00,'pending',NULL,'2026-04-21 23:24:54','2026-04-21 23:24:54'),(52,13,4,'2026-03-05',1618.00,'pending',NULL,'2026-04-21 23:24:54','2026-04-21 23:24:54'),(53,14,1,'2026-02-08',97.75,'paid','2026-03-02','2026-04-21 23:24:54','2026-04-21 23:24:54'),(54,14,2,'2026-05-08',97.75,'paid','2026-04-08','2026-04-21 23:24:54','2026-04-21 23:24:54'),(55,14,3,'2026-08-08',97.75,'pending',NULL,'2026-04-21 23:24:54','2026-04-21 23:24:54'),(56,14,4,'2026-11-08',97.75,'pending',NULL,'2026-04-21 23:24:54','2026-04-21 23:24:54'),(57,15,1,'2025-06-27',1039.50,'paid','2026-03-09','2026-04-21 23:24:55','2026-04-21 23:24:55'),(58,15,2,'2025-09-27',1039.50,'paid','2026-04-13','2026-04-21 23:24:55','2026-04-21 23:24:55'),(59,15,3,'2025-12-27',1039.50,'pending',NULL,'2026-04-21 23:24:55','2026-04-21 23:24:55'),(60,15,4,'2026-03-27',1039.50,'pending',NULL,'2026-04-21 23:24:55','2026-04-21 23:24:55'),(61,16,1,'2025-08-10',50.00,'paid','2026-04-11','2026-04-21 23:24:55','2026-04-21 23:24:55'),(62,16,2,'2025-11-10',50.00,'paid','2026-04-03','2026-04-21 23:24:56','2026-04-21 23:24:56'),(63,16,3,'2026-02-10',50.00,'pending',NULL,'2026-04-21 23:24:56','2026-04-21 23:24:56'),(64,16,4,'2026-05-10',50.00,'pending',NULL,'2026-04-21 23:24:56','2026-04-21 23:24:56'),(65,17,1,'2026-03-02',57.50,'paid','2026-03-22','2026-04-21 23:24:56','2026-04-21 23:24:56'),(66,17,2,'2026-06-02',57.50,'paid','2026-03-10','2026-04-21 23:24:56','2026-04-21 23:24:56'),(67,17,3,'2026-09-02',57.50,'pending',NULL,'2026-04-21 23:24:57','2026-04-21 23:24:57'),(68,17,4,'2026-12-02',57.50,'pending',NULL,'2026-04-21 23:24:57','2026-04-21 23:24:57'),(69,18,1,'2025-06-09',209.00,'paid','2026-03-17','2026-04-21 23:24:57','2026-04-21 23:24:57'),(70,18,2,'2025-09-09',209.00,'paid','2026-03-27','2026-04-21 23:24:57','2026-04-21 23:24:57'),(71,18,3,'2025-12-09',209.00,'pending',NULL,'2026-04-21 23:24:57','2026-04-21 23:24:57'),(72,18,4,'2026-03-09',209.00,'pending',NULL,'2026-04-21 23:24:58','2026-04-21 23:24:58'),(73,19,1,'2026-02-06',1103.00,'paid','2026-03-18','2026-04-21 23:24:58','2026-04-21 23:24:58'),(74,19,2,'2026-05-06',1103.00,'paid','2026-04-04','2026-04-21 23:24:58','2026-04-21 23:24:58'),(75,19,3,'2026-08-06',1103.00,'pending',NULL,'2026-04-21 23:24:58','2026-04-21 23:24:58'),(76,19,4,'2026-11-06',1103.00,'pending',NULL,'2026-04-21 23:24:58','2026-04-21 23:24:58'),(77,20,1,'2025-05-27',465.25,'paid','2026-04-04','2026-04-21 23:24:59','2026-04-21 23:24:59'),(78,20,2,'2025-08-27',465.25,'paid','2026-03-26','2026-04-21 23:24:59','2026-04-21 23:24:59'),(79,20,3,'2025-11-27',465.25,'pending',NULL,'2026-04-21 23:24:59','2026-04-21 23:24:59'),(80,20,4,'2026-02-27',465.25,'pending',NULL,'2026-04-21 23:24:59','2026-04-21 23:24:59'),(81,21,1,'2026-04-16',162.00,'paid','2026-03-13','2026-04-21 23:25:00','2026-04-21 23:25:00'),(82,21,2,'2026-07-16',162.00,'paid','2026-03-26','2026-04-21 23:25:00','2026-04-21 23:25:00'),(83,21,3,'2026-10-16',162.00,'pending',NULL,'2026-04-21 23:25:00','2026-04-21 23:25:00'),(84,21,4,'2027-01-16',162.00,'pending',NULL,'2026-04-21 23:25:00','2026-04-21 23:25:00'),(85,22,1,'2025-12-08',1052.75,'paid','2026-04-01','2026-04-21 23:25:00','2026-04-21 23:25:00'),(86,22,2,'2026-03-08',1052.75,'paid','2026-04-03','2026-04-21 23:25:00','2026-04-21 23:25:00'),(87,22,3,'2026-06-08',1052.75,'pending',NULL,'2026-04-21 23:25:00','2026-04-21 23:25:00'),(88,22,4,'2026-09-08',1052.75,'pending',NULL,'2026-04-21 23:25:01','2026-04-21 23:25:01'),(89,23,1,'2025-10-12',766.25,'paid','2026-02-22','2026-04-21 23:25:01','2026-04-21 23:25:01'),(90,23,2,'2026-01-12',766.25,'paid','2026-02-26','2026-04-21 23:25:01','2026-04-21 23:25:01'),(91,23,3,'2026-04-12',766.25,'pending',NULL,'2026-04-21 23:25:02','2026-04-21 23:25:02'),(92,23,4,'2026-07-12',766.25,'pending',NULL,'2026-04-21 23:25:02','2026-04-21 23:25:02'),(93,24,1,'2026-03-21',571.50,'paid','2026-03-05','2026-04-21 23:25:02','2026-04-21 23:25:02'),(94,24,2,'2026-06-21',571.50,'paid','2026-03-20','2026-04-21 23:25:02','2026-04-21 23:25:02'),(95,24,3,'2026-09-21',571.50,'pending',NULL,'2026-04-21 23:25:03','2026-04-21 23:25:03'),(96,24,4,'2026-12-21',571.50,'pending',NULL,'2026-04-21 23:25:03','2026-04-21 23:25:03'),(97,25,1,'2026-02-24',725.50,'paid','2026-03-20','2026-04-21 23:25:03','2026-04-21 23:25:03'),(98,25,2,'2026-05-24',725.50,'paid','2026-03-31','2026-04-21 23:25:03','2026-04-21 23:25:03'),(99,25,3,'2026-08-24',725.50,'pending',NULL,'2026-04-21 23:25:03','2026-04-21 23:25:03'),(100,25,4,'2026-11-24',725.50,'pending',NULL,'2026-04-21 23:25:03','2026-04-21 23:25:03'),(101,26,1,'2025-06-08',810.00,'paid','2026-04-14','2026-04-21 23:25:04','2026-04-21 23:25:04'),(102,26,2,'2025-09-08',810.00,'paid','2026-03-04','2026-04-21 23:25:04','2026-04-21 23:25:04'),(103,26,3,'2025-12-08',810.00,'pending',NULL,'2026-04-21 23:25:04','2026-04-21 23:25:04'),(104,26,4,'2026-03-08',810.00,'pending',NULL,'2026-04-21 23:25:04','2026-04-21 23:25:04'),(105,27,1,'2026-03-21',963.00,'paid','2026-02-21','2026-04-21 23:25:05','2026-04-21 23:25:05'),(106,27,2,'2026-06-21',963.00,'paid','2026-03-10','2026-04-21 23:25:05','2026-04-21 23:25:05'),(107,27,3,'2026-09-21',963.00,'pending',NULL,'2026-04-21 23:25:05','2026-04-21 23:25:05'),(108,27,4,'2026-12-21',963.00,'pending',NULL,'2026-04-21 23:25:05','2026-04-21 23:25:05'),(109,28,1,'2026-01-06',1313.00,'paid','2026-03-04','2026-04-21 23:25:05','2026-04-21 23:25:05'),(110,28,2,'2026-04-06',1313.00,'paid','2026-04-15','2026-04-21 23:25:05','2026-04-21 23:25:05'),(111,28,3,'2026-07-06',1313.00,'pending',NULL,'2026-04-21 23:25:06','2026-04-21 23:25:06'),(112,28,4,'2026-10-06',1313.00,'pending',NULL,'2026-04-21 23:25:06','2026-04-21 23:25:06'),(113,29,1,'2025-12-08',1022.75,'paid','2026-03-04','2026-04-21 23:25:06','2026-04-21 23:25:06'),(114,29,2,'2026-03-08',1022.75,'paid','2026-03-19','2026-04-21 23:25:06','2026-04-21 23:25:06'),(115,29,3,'2026-06-08',1022.75,'pending',NULL,'2026-04-21 23:25:07','2026-04-21 23:25:07'),(116,29,4,'2026-09-08',1022.75,'pending',NULL,'2026-04-21 23:25:07','2026-04-21 23:25:07'),(117,30,1,'2026-04-19',1364.00,'paid','2026-03-01','2026-04-21 23:25:07','2026-04-21 23:25:07'),(118,30,2,'2026-07-19',1364.00,'paid','2026-03-13','2026-04-21 23:25:07','2026-04-21 23:25:07'),(119,30,3,'2026-10-19',1364.00,'pending',NULL,'2026-04-21 23:25:07','2026-04-21 23:25:07'),(120,30,4,'2027-01-19',1364.00,'pending',NULL,'2026-04-21 23:25:07','2026-04-21 23:25:07'),(121,31,1,'2025-08-17',336.75,'paid','2026-04-19','2026-04-21 23:25:08','2026-04-21 23:25:08'),(122,31,2,'2025-11-17',336.75,'paid','2026-04-02','2026-04-21 23:25:08','2026-04-21 23:25:08'),(123,31,3,'2026-02-17',336.75,'pending',NULL,'2026-04-21 23:25:08','2026-04-21 23:25:08'),(124,31,4,'2026-05-17',336.75,'pending',NULL,'2026-04-21 23:25:08','2026-04-21 23:25:08'),(125,32,1,'2025-12-17',517.25,'paid','2026-04-09','2026-04-21 23:25:09','2026-04-21 23:25:09'),(126,32,2,'2026-03-17',517.25,'paid','2026-03-21','2026-04-21 23:25:09','2026-04-21 23:25:09'),(127,32,3,'2026-06-17',517.25,'pending',NULL,'2026-04-21 23:25:09','2026-04-21 23:25:09'),(128,32,4,'2026-09-17',517.25,'pending',NULL,'2026-04-21 23:25:09','2026-04-21 23:25:09'),(129,33,1,'2025-12-06',1505.25,'paid','2026-02-27','2026-04-21 23:25:09','2026-04-21 23:25:09'),(130,33,2,'2026-03-06',1505.25,'paid','2026-04-18','2026-04-21 23:25:10','2026-04-21 23:25:10'),(131,33,3,'2026-06-06',1505.25,'pending',NULL,'2026-04-21 23:25:10','2026-04-21 23:25:10'),(132,33,4,'2026-09-06',1505.25,'pending',NULL,'2026-04-21 23:25:10','2026-04-21 23:25:10'),(133,34,1,'2025-05-26',1079.25,'paid','2026-04-09','2026-04-21 23:25:10','2026-04-21 23:25:10'),(134,34,2,'2025-08-26',1079.25,'paid','2026-03-24','2026-04-21 23:25:10','2026-04-21 23:25:10'),(135,34,3,'2025-11-26',1079.25,'pending',NULL,'2026-04-21 23:25:10','2026-04-21 23:25:10'),(136,34,4,'2026-02-26',1079.25,'pending',NULL,'2026-04-21 23:25:10','2026-04-21 23:25:10'),(137,35,1,'2026-03-01',243.00,'paid','2026-03-02','2026-04-21 23:25:11','2026-04-21 23:25:11'),(138,35,2,'2026-06-01',243.00,'paid','2026-04-03','2026-04-21 23:25:11','2026-04-21 23:25:11'),(139,35,3,'2026-09-01',243.00,'pending',NULL,'2026-04-21 23:25:11','2026-04-21 23:25:11'),(140,35,4,'2026-12-01',243.00,'pending',NULL,'2026-04-21 23:25:11','2026-04-21 23:25:11'),(141,36,1,'2025-09-01',937.50,'paid','2026-04-02','2026-04-21 23:25:12','2026-04-21 23:25:12'),(142,36,2,'2025-12-01',937.50,'paid','2026-04-16','2026-04-21 23:25:12','2026-04-21 23:25:12'),(143,36,3,'2026-03-01',937.50,'pending',NULL,'2026-04-21 23:25:12','2026-04-21 23:25:12'),(144,36,4,'2026-06-01',937.50,'pending',NULL,'2026-04-21 23:25:12','2026-04-21 23:25:12'),(145,37,1,'2025-10-09',1365.00,'paid','2026-04-19','2026-04-21 23:25:12','2026-04-21 23:25:12'),(146,37,2,'2026-01-09',1365.00,'paid','2026-04-15','2026-04-21 23:25:12','2026-04-21 23:25:12'),(147,37,3,'2026-04-09',1365.00,'pending',NULL,'2026-04-21 23:25:13','2026-04-21 23:25:13'),(148,37,4,'2026-07-09',1365.00,'pending',NULL,'2026-04-21 23:25:13','2026-04-21 23:25:13'),(149,38,1,'2026-03-16',503.25,'paid','2026-02-26','2026-04-21 23:25:13','2026-04-21 23:25:13'),(150,38,2,'2026-06-16',503.25,'paid','2026-03-04','2026-04-21 23:25:13','2026-04-21 23:25:13'),(151,38,3,'2026-09-16',503.25,'pending',NULL,'2026-04-21 23:25:13','2026-04-21 23:25:13'),(152,38,4,'2026-12-16',503.25,'pending',NULL,'2026-04-21 23:25:14','2026-04-21 23:25:14'),(153,39,1,'2025-12-07',575.50,'paid','2026-03-30','2026-04-21 23:25:14','2026-04-21 23:25:14'),(154,39,2,'2026-03-07',575.50,'paid','2026-03-14','2026-04-21 23:25:14','2026-04-21 23:25:14'),(155,39,3,'2026-06-07',575.50,'pending',NULL,'2026-04-21 23:25:14','2026-04-21 23:25:14'),(156,39,4,'2026-09-07',575.50,'pending',NULL,'2026-04-21 23:25:14','2026-04-21 23:25:14'),(157,40,1,'2025-05-03',920.25,'paid','2026-03-17','2026-04-21 23:25:15','2026-04-21 23:25:15'),(158,40,2,'2025-08-03',920.25,'paid','2026-03-14','2026-04-21 23:25:15','2026-04-21 23:25:15'),(159,40,3,'2025-11-03',920.25,'pending',NULL,'2026-04-21 23:25:15','2026-04-21 23:25:15'),(160,40,4,'2026-02-03',920.25,'pending',NULL,'2026-04-21 23:25:15','2026-04-21 23:25:15'),(161,41,1,'2025-07-29',84.50,'paid','2026-04-16','2026-04-21 23:25:15','2026-04-21 23:25:15'),(162,41,2,'2025-10-29',84.50,'paid','2026-04-01','2026-04-21 23:25:15','2026-04-21 23:25:15'),(163,41,3,'2026-01-29',84.50,'pending',NULL,'2026-04-21 23:25:16','2026-04-21 23:25:16'),(164,41,4,'2026-04-29',84.50,'pending',NULL,'2026-04-21 23:25:16','2026-04-21 23:25:16'),(165,42,1,'2026-04-08',729.75,'paid','2026-03-09','2026-04-21 23:25:16','2026-04-21 23:25:16'),(166,42,2,'2026-07-08',729.75,'paid','2026-04-18','2026-04-21 23:25:16','2026-04-21 23:25:16'),(167,42,3,'2026-10-08',729.75,'pending',NULL,'2026-04-21 23:25:16','2026-04-21 23:25:16'),(168,42,4,'2027-01-08',729.75,'pending',NULL,'2026-04-21 23:25:16','2026-04-21 23:25:16'),(169,43,1,'2025-10-01',256.50,'paid','2026-04-10','2026-04-21 23:25:17','2026-04-21 23:25:17'),(170,43,2,'2026-01-01',256.50,'paid','2026-03-07','2026-04-21 23:25:17','2026-04-21 23:25:17'),(171,43,3,'2026-04-01',256.50,'pending',NULL,'2026-04-21 23:25:17','2026-04-21 23:25:17'),(172,43,4,'2026-07-01',256.50,'pending',NULL,'2026-04-21 23:25:17','2026-04-21 23:25:17'),(173,44,1,'2026-04-20',977.75,'paid','2026-04-19','2026-04-21 23:25:18','2026-04-21 23:25:18'),(174,44,2,'2026-07-20',977.75,'paid','2026-03-30','2026-04-21 23:25:18','2026-04-21 23:25:18'),(175,44,3,'2026-10-20',977.75,'pending',NULL,'2026-04-21 23:25:18','2026-04-21 23:25:18'),(176,44,4,'2027-01-20',977.75,'pending',NULL,'2026-04-21 23:25:18','2026-04-21 23:25:18'),(177,45,1,'2026-04-07',941.25,'paid','2026-04-11','2026-04-21 23:25:18','2026-04-21 23:25:18'),(178,45,2,'2026-07-07',941.25,'paid','2026-04-02','2026-04-21 23:25:18','2026-04-21 23:25:18'),(179,45,3,'2026-10-07',941.25,'pending',NULL,'2026-04-21 23:25:18','2026-04-21 23:25:18'),(180,45,4,'2027-01-07',941.25,'pending',NULL,'2026-04-21 23:25:19','2026-04-21 23:25:19'),(181,46,1,'2026-03-03',1179.00,'paid','2026-03-29','2026-04-21 23:25:19','2026-04-21 23:25:19'),(182,46,2,'2026-06-03',1179.00,'paid','2026-03-30','2026-04-21 23:25:19','2026-04-21 23:25:19'),(183,46,3,'2026-09-03',1179.00,'pending',NULL,'2026-04-21 23:25:19','2026-04-21 23:25:19'),(184,46,4,'2026-12-03',1179.00,'pending',NULL,'2026-04-21 23:25:19','2026-04-21 23:25:19'),(185,47,1,'2025-05-07',828.00,'paid','2026-02-23','2026-04-21 23:25:20','2026-04-21 23:25:20'),(186,47,2,'2025-08-07',828.00,'paid','2026-03-02','2026-04-21 23:25:20','2026-04-21 23:25:20'),(187,47,3,'2025-11-07',828.00,'pending',NULL,'2026-04-21 23:25:20','2026-04-21 23:25:20'),(188,47,4,'2026-02-07',828.00,'pending',NULL,'2026-04-21 23:25:20','2026-04-21 23:25:20'),(189,48,1,'2025-10-07',1255.25,'paid','2026-04-10','2026-04-21 23:25:21','2026-04-21 23:25:21'),(190,48,2,'2026-01-07',1255.25,'paid','2026-04-03','2026-04-21 23:25:21','2026-04-21 23:25:21'),(191,48,3,'2026-04-07',1255.25,'pending',NULL,'2026-04-21 23:25:21','2026-04-21 23:25:21'),(192,48,4,'2026-07-07',1255.25,'pending',NULL,'2026-04-21 23:25:21','2026-04-21 23:25:21'),(193,49,1,'2025-11-03',205.25,'paid','2026-03-31','2026-04-21 23:25:22','2026-04-21 23:25:22'),(194,49,2,'2026-02-03',205.25,'paid','2026-03-06','2026-04-21 23:25:22','2026-04-21 23:25:22'),(195,49,3,'2026-05-03',205.25,'pending',NULL,'2026-04-21 23:25:22','2026-04-21 23:25:22'),(196,49,4,'2026-08-03',205.25,'pending',NULL,'2026-04-21 23:25:22','2026-04-21 23:25:22'),(197,50,1,'2026-01-17',1142.50,'paid','2026-03-11','2026-04-21 23:25:23','2026-04-21 23:25:23'),(198,50,2,'2026-04-17',1142.50,'paid','2026-04-02','2026-04-21 23:25:23','2026-04-21 23:25:23'),(199,50,3,'2026-07-17',1142.50,'pending',NULL,'2026-04-21 23:25:23','2026-04-21 23:25:23'),(200,50,4,'2026-10-17',1142.50,'pending',NULL,'2026-04-21 23:25:23','2026-04-21 23:25:23'),(201,51,1,'2025-07-04',1562.50,'paid','2026-03-09','2026-04-21 23:25:23','2026-04-21 23:25:23'),(202,51,2,'2025-10-04',1562.50,'paid','2026-03-07','2026-04-21 23:25:23','2026-04-21 23:25:23'),(203,51,3,'2026-01-04',1562.50,'pending',NULL,'2026-04-21 23:25:24','2026-04-21 23:25:24'),(204,51,4,'2026-04-04',1562.50,'pending',NULL,'2026-04-21 23:25:24','2026-04-21 23:25:24'),(205,52,1,'2025-09-13',122.25,'paid','2026-03-08','2026-04-21 23:25:24','2026-04-21 23:25:24'),(206,52,2,'2025-12-13',122.25,'paid','2026-02-25','2026-04-21 23:25:24','2026-04-21 23:25:24'),(207,52,3,'2026-03-13',122.25,'pending',NULL,'2026-04-21 23:25:24','2026-04-21 23:25:24'),(208,52,4,'2026-06-13',122.25,'pending',NULL,'2026-04-21 23:25:24','2026-04-21 23:25:24'),(209,53,1,'2025-10-04',1309.25,'paid','2026-03-03','2026-04-21 23:25:25','2026-04-21 23:25:25'),(210,53,2,'2026-01-04',1309.25,'paid','2026-04-12','2026-04-21 23:25:25','2026-04-21 23:25:25'),(211,53,3,'2026-04-04',1309.25,'pending',NULL,'2026-04-21 23:25:25','2026-04-21 23:25:25'),(212,53,4,'2026-07-04',1309.25,'pending',NULL,'2026-04-21 23:25:25','2026-04-21 23:25:25'),(213,54,1,'2025-08-08',1425.25,'paid','2026-04-19','2026-04-21 23:25:26','2026-04-21 23:25:26'),(214,54,2,'2025-11-08',1425.25,'paid','2026-04-20','2026-04-21 23:25:26','2026-04-21 23:25:26'),(215,54,3,'2026-02-08',1425.25,'pending',NULL,'2026-04-21 23:25:26','2026-04-21 23:25:26'),(216,54,4,'2026-05-08',1425.25,'pending',NULL,'2026-04-21 23:25:26','2026-04-21 23:25:26'),(217,55,1,'2025-11-07',783.50,'paid','2026-03-08','2026-04-21 23:25:26','2026-04-21 23:25:26'),(218,55,2,'2026-02-07',783.50,'paid','2026-04-07','2026-04-21 23:25:26','2026-04-21 23:25:26'),(219,55,3,'2026-05-07',783.50,'pending',NULL,'2026-04-21 23:25:26','2026-04-21 23:25:26'),(220,55,4,'2026-08-07',783.50,'pending',NULL,'2026-04-21 23:25:26','2026-04-21 23:25:26'),(221,56,1,'2026-03-15',341.50,'paid','2026-04-12','2026-04-21 23:25:27','2026-04-21 23:25:27'),(222,56,2,'2026-06-15',341.50,'paid','2026-02-27','2026-04-21 23:25:27','2026-04-21 23:25:27'),(223,56,3,'2026-09-15',341.50,'pending',NULL,'2026-04-21 23:25:27','2026-04-21 23:25:27'),(224,56,4,'2026-12-15',341.50,'pending',NULL,'2026-04-21 23:25:27','2026-04-21 23:25:27'),(225,57,1,'2026-01-02',1014.75,'paid','2026-04-12','2026-04-21 23:25:28','2026-04-21 23:25:28'),(226,57,2,'2026-04-02',1014.75,'paid','2026-02-22','2026-04-21 23:25:28','2026-04-21 23:25:28'),(227,57,3,'2026-07-02',1014.75,'pending',NULL,'2026-04-21 23:25:28','2026-04-21 23:25:28'),(228,57,4,'2026-10-02',1014.75,'pending',NULL,'2026-04-21 23:25:28','2026-04-21 23:25:28'),(229,58,1,'2026-02-17',76.75,'paid','2026-04-03','2026-04-21 23:25:28','2026-04-21 23:25:28'),(230,58,2,'2026-05-17',76.75,'paid','2026-03-02','2026-04-21 23:25:29','2026-04-21 23:25:29'),(231,58,3,'2026-08-17',76.75,'pending',NULL,'2026-04-21 23:25:29','2026-04-21 23:25:29'),(232,58,4,'2026-11-17',76.75,'pending',NULL,'2026-04-21 23:25:29','2026-04-21 23:25:29'),(233,59,1,'2026-02-05',684.00,'paid','2026-04-19','2026-04-21 23:25:29','2026-04-21 23:25:29'),(234,59,2,'2026-05-05',684.00,'paid','2026-03-10','2026-04-21 23:25:29','2026-04-21 23:25:29'),(235,59,3,'2026-08-05',684.00,'pending',NULL,'2026-04-21 23:25:29','2026-04-21 23:25:29'),(236,59,4,'2026-11-05',684.00,'pending',NULL,'2026-04-21 23:25:29','2026-04-21 23:25:29'),(237,60,1,'2025-05-05',457.00,'paid','2026-02-23','2026-04-21 23:25:30','2026-04-21 23:25:30'),(238,60,2,'2025-08-05',457.00,'paid','2026-04-14','2026-04-21 23:25:30','2026-04-21 23:25:30'),(239,60,3,'2025-11-05',457.00,'pending',NULL,'2026-04-21 23:25:30','2026-04-21 23:25:30'),(240,60,4,'2026-02-05',457.00,'pending',NULL,'2026-04-21 23:25:30','2026-04-21 23:25:30'),(241,61,1,'2026-04-22',29.53,'pending',NULL,'2026-04-21 23:40:26','2026-04-21 23:40:26'),(242,61,2,'2026-05-22',29.53,'pending',NULL,'2026-04-21 23:40:26','2026-04-21 23:40:26'),(243,61,3,'2026-06-22',29.53,'pending',NULL,'2026-04-21 23:40:26','2026-04-21 23:40:26'),(244,61,4,'2026-07-22',29.53,'pending',NULL,'2026-04-21 23:40:26','2026-04-21 23:40:26'),(245,61,5,'2026-08-22',29.53,'pending',NULL,'2026-04-21 23:40:26','2026-04-21 23:40:26'),(246,61,6,'2026-09-22',29.53,'pending',NULL,'2026-04-21 23:40:26','2026-04-21 23:40:26'),(247,61,7,'2026-10-22',29.53,'pending',NULL,'2026-04-21 23:40:26','2026-04-21 23:40:26'),(248,61,8,'2026-11-22',29.53,'pending',NULL,'2026-04-21 23:40:26','2026-04-21 23:40:26'),(249,61,9,'2026-12-22',29.53,'pending',NULL,'2026-04-21 23:40:26','2026-04-21 23:40:26'),(250,61,10,'2027-01-22',29.53,'pending',NULL,'2026-04-21 23:40:26','2026-04-21 23:40:26'),(251,61,11,'2027-02-22',29.53,'pending',NULL,'2026-04-21 23:40:26','2026-04-21 23:40:26'),(252,61,12,'2027-03-22',29.55,'pending',NULL,'2026-04-21 23:40:26','2026-04-21 23:40:26');
/*!40000 ALTER TABLE `policy_installments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `reinsurance_distributions`
--

DROP TABLE IF EXISTS `reinsurance_distributions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `reinsurance_distributions` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `policy_id` bigint unsigned NOT NULL,
  `reinsurance_treaty_id` bigint unsigned NOT NULL,
  `policy_premium` decimal(14,2) NOT NULL,
  `ri_share_amount` decimal(14,2) NOT NULL,
  `claims_recovered` decimal(14,2) NOT NULL DEFAULT '0.00',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `reinsurance_distributions_policy_id_foreign` (`policy_id`),
  KEY `reinsurance_distributions_reinsurance_treaty_id_foreign` (`reinsurance_treaty_id`),
  CONSTRAINT `reinsurance_distributions_policy_id_foreign` FOREIGN KEY (`policy_id`) REFERENCES `policies` (`id`) ON DELETE CASCADE,
  CONSTRAINT `reinsurance_distributions_reinsurance_treaty_id_foreign` FOREIGN KEY (`reinsurance_treaty_id`) REFERENCES `reinsurance_treaties` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `reinsurance_distributions`
--

LOCK TABLES `reinsurance_distributions` WRITE;
/*!40000 ALTER TABLE `reinsurance_distributions` DISABLE KEYS */;
INSERT INTO `reinsurance_distributions` VALUES (1,61,1,354.38,88.60,0.00,'2026-04-21 23:40:27','2026-04-21 23:40:27'),(2,61,2,354.38,35.44,0.00,'2026-04-21 23:40:27','2026-04-21 23:40:27');
/*!40000 ALTER TABLE `reinsurance_distributions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `reinsurance_treaties`
--

DROP TABLE IF EXISTS `reinsurance_treaties`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `reinsurance_treaties` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `reinsurer` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` enum('quota_share','excess_of_loss') COLLATE utf8mb4_unicode_ci NOT NULL,
  `share_pct` decimal(5,2) NOT NULL DEFAULT '0.00',
  `retention` decimal(14,2) NOT NULL DEFAULT '0.00',
  `effective_from` date NOT NULL,
  `effective_to` date DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `reinsurance_treaties`
--

LOCK TABLES `reinsurance_treaties` WRITE;
/*!40000 ALTER TABLE `reinsurance_treaties` DISABLE KEYS */;
INSERT INTO `reinsurance_treaties` VALUES (1,'Saudi Re','quota_share',25.00,5000.00,'2025-04-22',NULL,1,'2026-04-21 23:24:43','2026-04-21 23:24:43'),(2,'Arab Re','excess_of_loss',10.00,10000.00,'2025-04-22',NULL,1,'2026-04-21 23:24:43','2026-04-21 23:24:43');
/*!40000 ALTER TABLE `reinsurance_treaties` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sessions`
--

DROP TABLE IF EXISTS `sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sessions` (
  `id` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` bigint unsigned DEFAULT NULL,
  `ip_address` varchar(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_agent` text COLLATE utf8mb4_unicode_ci,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `last_activity` int NOT NULL,
  PRIMARY KEY (`id`),
  KEY `sessions_user_id_index` (`user_id`),
  KEY `sessions_last_activity_index` (`last_activity`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sessions`
--

LOCK TABLES `sessions` WRITE;
/*!40000 ALTER TABLE `sessions` DISABLE KEYS */;
INSERT INTO `sessions` VALUES ('X3HeBQMRQE6TrObtYHnTSiwlaVFDvNbWJONyBMgH',2,'127.0.0.1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36','YTo1OntzOjY6Il90b2tlbiI7czo0MDoiRnB5d2VhazNHOGVqZW5CdHluZE1FZXg1U25iZmFDVlZ5MzdoaDFNRiI7czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MzA6Imh0dHA6Ly8xMjcuMC4wLjE6ODAwMC9wb2xpY2llcyI7fXM6MzoidXJsIjthOjA6e31zOjUwOiJsb2dpbl93ZWJfNTliYTM2YWRkYzJiMmY5NDAxNTgwZjAxNGM3ZjU4ZWE0ZTMwOTg5ZCI7aToyO30=',1776823335);
/*!40000 ALTER TABLE `sessions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tariff_rates`
--

DROP TABLE IF EXISTS `tariff_rates`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tariff_rates` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `insurance_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `base_rate` decimal(8,4) NOT NULL,
  `min_premium` decimal(12,2) NOT NULL DEFAULT '0.00',
  `rules` json DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tariff_rates`
--

LOCK TABLES `tariff_rates` WRITE;
/*!40000 ALTER TABLE `tariff_rates` DISABLE KEYS */;
INSERT INTO `tariff_rates` VALUES (1,'health',0.0180,250.00,'{\"age_loading\": true}',1,'2026-04-21 23:24:42','2026-04-21 23:24:42'),(2,'car',0.0250,120.00,'{\"young_driver_loading\": 0.75}',1,'2026-04-21 23:24:42','2026-04-21 23:24:42'),(3,'fire',0.0150,300.00,'{\"sprinklers_discount\": 0.1}',1,'2026-04-21 23:24:42','2026-04-21 23:24:42'),(4,'marine',0.0110,400.00,'{\"packing_loading\": 0.08}',1,'2026-04-21 23:24:42','2026-04-21 23:24:42'),(5,'engineering',0.0130,500.00,'{\"project_type_factor\": true}',1,'2026-04-21 23:24:42','2026-04-21 23:24:42'),(6,'liability',0.0090,220.00,'{\"limit_based\": true}',1,'2026-04-21 23:24:42','2026-04-21 23:24:42');
/*!40000 ALTER TABLE `tariff_rates` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `transactions`
--

DROP TABLE IF EXISTS `transactions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `transactions` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `transaction_no` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `policy_id` bigint unsigned DEFAULT NULL,
  `claim_id` bigint unsigned DEFAULT NULL,
  `type` enum('policy_issue','premium_collection','claim_payment','policy_refund','endorsement') COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` enum('pending','completed','failed','cancelled') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'pending',
  `amount` decimal(14,2) NOT NULL,
  `currency` varchar(3) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'JOD',
  `transaction_date` timestamp NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `transactions_transaction_no_unique` (`transaction_no`),
  KEY `transactions_policy_id_foreign` (`policy_id`),
  KEY `transactions_claim_id_foreign` (`claim_id`),
  CONSTRAINT `transactions_claim_id_foreign` FOREIGN KEY (`claim_id`) REFERENCES `claims` (`id`) ON DELETE SET NULL,
  CONSTRAINT `transactions_policy_id_foreign` FOREIGN KEY (`policy_id`) REFERENCES `policies` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=82 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `transactions`
--

LOCK TABLES `transactions` WRITE;
/*!40000 ALTER TABLE `transactions` DISABLE KEYS */;
INSERT INTO `transactions` VALUES (1,'TXN-SD-000001',1,NULL,'policy_issue','completed',1662.00,'SAR','2025-12-13 23:24:44','2026-04-21 23:24:44','2026-04-21 23:24:44'),(2,'TXN-CLM-000001',1,1,'claim_payment','pending',4726.15,'SAR','2026-04-21 23:24:45','2026-04-21 23:24:45','2026-04-21 23:24:45'),(3,'TXN-SD-000002',2,NULL,'policy_issue','completed',6480.00,'SAR','2025-07-19 22:24:45','2026-04-21 23:24:45','2026-04-21 23:24:45'),(4,'TXN-SD-000003',3,NULL,'policy_issue','completed',6057.00,'SAR','2025-10-13 22:24:45','2026-04-21 23:24:46','2026-04-21 23:24:46'),(5,'TXN-SD-000004',4,NULL,'policy_issue','completed',2781.00,'SAR','2026-01-03 23:24:46','2026-04-21 23:24:47','2026-04-21 23:24:47'),(6,'TXN-CLM-000004',4,2,'claim_payment','pending',1960.20,'SAR','2026-04-21 23:24:47','2026-04-21 23:24:47','2026-04-21 23:24:47'),(7,'TXN-SD-000005',5,NULL,'policy_issue','completed',2936.00,'SAR','2025-08-26 22:24:47','2026-04-21 23:24:48','2026-04-21 23:24:48'),(8,'TXN-SD-000006',6,NULL,'policy_issue','completed',2529.00,'SAR','2025-10-01 22:24:48','2026-04-21 23:24:48','2026-04-21 23:24:48'),(9,'TXN-SD-000007',7,NULL,'policy_issue','completed',685.00,'SAR','2025-05-15 22:24:49','2026-04-21 23:24:49','2026-04-21 23:24:49'),(10,'TXN-CLM-000007',7,3,'claim_payment','pending',3082.75,'SAR','2026-04-21 23:24:49','2026-04-21 23:24:49','2026-04-21 23:24:49'),(11,'TXN-SD-000008',8,NULL,'policy_issue','completed',4315.00,'SAR','2025-07-31 22:24:49','2026-04-21 23:24:50','2026-04-21 23:24:50'),(12,'TXN-SD-000009',9,NULL,'policy_issue','completed',234.00,'SAR','2025-07-25 22:24:50','2026-04-21 23:24:51','2026-04-21 23:24:51'),(13,'TXN-SD-000010',10,NULL,'policy_issue','completed',1593.00,'SAR','2026-04-18 23:24:51','2026-04-21 23:24:52','2026-04-21 23:24:52'),(14,'TXN-CLM-000010',10,4,'claim_payment','pending',441.65,'SAR','2026-04-21 23:24:52','2026-04-21 23:24:52','2026-04-21 23:24:52'),(15,'TXN-SD-000011',11,NULL,'policy_issue','completed',1222.00,'SAR','2025-09-28 22:24:52','2026-04-21 23:24:52','2026-04-21 23:24:52'),(16,'TXN-SD-000012',12,NULL,'policy_issue','completed',3502.00,'SAR','2025-04-30 22:24:53','2026-04-21 23:24:53','2026-04-21 23:24:53'),(17,'TXN-SD-000013',13,NULL,'policy_issue','completed',6472.00,'SAR','2025-06-04 22:24:53','2026-04-21 23:24:54','2026-04-21 23:24:54'),(18,'TXN-CLM-000013',13,5,'claim_payment','pending',2437.05,'SAR','2026-04-21 23:24:54','2026-04-21 23:24:54','2026-04-21 23:24:54'),(19,'TXN-SD-000014',14,NULL,'policy_issue','completed',391.00,'SAR','2026-02-07 23:24:54','2026-04-21 23:24:55','2026-04-21 23:24:55'),(20,'TXN-SD-000015',15,NULL,'policy_issue','completed',4158.00,'SAR','2025-06-26 22:24:55','2026-04-21 23:24:55','2026-04-21 23:24:55'),(21,'TXN-SD-000016',16,NULL,'policy_issue','completed',200.00,'SAR','2025-08-09 22:24:55','2026-04-21 23:24:56','2026-04-21 23:24:56'),(22,'TXN-CLM-000016',16,6,'claim_payment','pending',4764.10,'SAR','2026-04-21 23:24:56','2026-04-21 23:24:56','2026-04-21 23:24:56'),(23,'TXN-SD-000017',17,NULL,'policy_issue','completed',230.00,'SAR','2026-03-01 23:24:56','2026-04-21 23:24:57','2026-04-21 23:24:57'),(24,'TXN-SD-000018',18,NULL,'policy_issue','completed',836.00,'SAR','2025-06-08 22:24:57','2026-04-21 23:24:58','2026-04-21 23:24:58'),(25,'TXN-SD-000019',19,NULL,'policy_issue','completed',4412.00,'SAR','2026-02-05 23:24:58','2026-04-21 23:24:58','2026-04-21 23:24:58'),(26,'TXN-CLM-000019',19,7,'claim_payment','pending',3474.90,'SAR','2026-04-21 23:24:59','2026-04-21 23:24:59','2026-04-21 23:24:59'),(27,'TXN-SD-000020',20,NULL,'policy_issue','completed',1861.00,'SAR','2025-05-26 22:24:59','2026-04-21 23:24:59','2026-04-21 23:24:59'),(28,'TXN-SD-000021',21,NULL,'policy_issue','completed',648.00,'SAR','2026-04-15 23:25:00','2026-04-21 23:25:00','2026-04-21 23:25:00'),(29,'TXN-SD-000022',22,NULL,'policy_issue','completed',4211.00,'SAR','2025-12-07 23:25:00','2026-04-21 23:25:01','2026-04-21 23:25:01'),(30,'TXN-CLM-000022',22,8,'claim_payment','completed',5904.25,'SAR','2026-04-21 23:25:01','2026-04-21 23:25:01','2026-04-21 23:25:01'),(31,'TXN-SD-000023',23,NULL,'policy_issue','completed',3065.00,'SAR','2025-10-11 22:25:01','2026-04-21 23:25:02','2026-04-21 23:25:02'),(32,'TXN-SD-000024',24,NULL,'policy_issue','completed',2286.00,'SAR','2026-03-20 23:25:02','2026-04-21 23:25:03','2026-04-21 23:25:03'),(33,'TXN-SD-000025',25,NULL,'policy_issue','completed',2902.00,'SAR','2026-02-23 23:25:03','2026-04-21 23:25:04','2026-04-21 23:25:04'),(34,'TXN-CLM-000025',25,9,'claim_payment','pending',2516.80,'SAR','2026-04-21 23:25:04','2026-04-21 23:25:04','2026-04-21 23:25:04'),(35,'TXN-SD-000026',26,NULL,'policy_issue','completed',3240.00,'SAR','2025-06-07 22:25:04','2026-04-21 23:25:05','2026-04-21 23:25:05'),(36,'TXN-SD-000027',27,NULL,'policy_issue','completed',3852.00,'SAR','2026-03-20 23:25:05','2026-04-21 23:25:05','2026-04-21 23:25:05'),(37,'TXN-SD-000028',28,NULL,'policy_issue','completed',5252.00,'SAR','2026-01-05 23:25:05','2026-04-21 23:25:06','2026-04-21 23:25:06'),(38,'TXN-CLM-000028',28,10,'claim_payment','pending',1395.35,'SAR','2026-04-21 23:25:06','2026-04-21 23:25:06','2026-04-21 23:25:06'),(39,'TXN-SD-000029',29,NULL,'policy_issue','completed',4091.00,'SAR','2025-12-07 23:25:06','2026-04-21 23:25:07','2026-04-21 23:25:07'),(40,'TXN-SD-000030',30,NULL,'policy_issue','completed',5456.00,'SAR','2026-04-18 23:25:07','2026-04-21 23:25:07','2026-04-21 23:25:07'),(41,'TXN-SD-000031',31,NULL,'policy_issue','completed',1347.00,'SAR','2025-08-16 22:25:08','2026-04-21 23:25:08','2026-04-21 23:25:08'),(42,'TXN-CLM-000031',31,11,'claim_payment','pending',3851.65,'SAR','2026-04-21 23:25:08','2026-04-21 23:25:09','2026-04-21 23:25:09'),(43,'TXN-SD-000032',32,NULL,'policy_issue','completed',2069.00,'SAR','2025-12-16 23:25:09','2026-04-21 23:25:09','2026-04-21 23:25:09'),(44,'TXN-SD-000033',33,NULL,'policy_issue','completed',6021.00,'SAR','2025-12-05 23:25:09','2026-04-21 23:25:10','2026-04-21 23:25:10'),(45,'TXN-SD-000034',34,NULL,'policy_issue','completed',4317.00,'SAR','2025-05-25 22:25:10','2026-04-21 23:25:10','2026-04-21 23:25:10'),(46,'TXN-CLM-000034',34,12,'claim_payment','pending',4232.80,'SAR','2026-04-21 23:25:11','2026-04-21 23:25:11','2026-04-21 23:25:11'),(47,'TXN-SD-000035',35,NULL,'policy_issue','completed',972.00,'SAR','2026-02-28 23:25:11','2026-04-21 23:25:11','2026-04-21 23:25:11'),(48,'TXN-SD-000036',36,NULL,'policy_issue','completed',3750.00,'SAR','2025-08-31 22:25:12','2026-04-21 23:25:12','2026-04-21 23:25:12'),(49,'TXN-SD-000037',37,NULL,'policy_issue','completed',5460.00,'SAR','2025-10-08 22:25:12','2026-04-21 23:25:13','2026-04-21 23:25:13'),(50,'TXN-CLM-000037',37,13,'claim_payment','pending',2440.35,'SAR','2026-04-21 23:25:13','2026-04-21 23:25:13','2026-04-21 23:25:13'),(51,'TXN-SD-000038',38,NULL,'policy_issue','completed',2013.00,'SAR','2026-03-15 23:25:13','2026-04-21 23:25:14','2026-04-21 23:25:14'),(52,'TXN-SD-000039',39,NULL,'policy_issue','completed',2302.00,'SAR','2025-12-06 23:25:14','2026-04-21 23:25:14','2026-04-21 23:25:14'),(53,'TXN-SD-000040',40,NULL,'policy_issue','completed',3681.00,'SAR','2025-05-02 22:25:14','2026-04-21 23:25:15','2026-04-21 23:25:15'),(54,'TXN-CLM-000040',40,14,'claim_payment','pending',5374.05,'SAR','2026-04-21 23:25:15','2026-04-21 23:25:15','2026-04-21 23:25:15'),(55,'TXN-SD-000041',41,NULL,'policy_issue','completed',338.00,'SAR','2025-07-28 22:25:15','2026-04-21 23:25:16','2026-04-21 23:25:16'),(56,'TXN-SD-000042',42,NULL,'policy_issue','completed',2919.00,'SAR','2026-04-07 23:25:16','2026-04-21 23:25:16','2026-04-21 23:25:16'),(57,'TXN-SD-000043',43,NULL,'policy_issue','completed',1026.00,'SAR','2025-09-30 22:25:17','2026-04-21 23:25:17','2026-04-21 23:25:17'),(58,'TXN-CLM-000043',43,15,'claim_payment','completed',2138.40,'SAR','2026-04-21 23:25:17','2026-04-21 23:25:17','2026-04-21 23:25:17'),(59,'TXN-SD-000044',44,NULL,'policy_issue','completed',3911.00,'SAR','2026-04-19 23:25:17','2026-04-21 23:25:18','2026-04-21 23:25:18'),(60,'TXN-SD-000045',45,NULL,'policy_issue','completed',3765.00,'SAR','2026-04-06 23:25:18','2026-04-21 23:25:19','2026-04-21 23:25:19'),(61,'TXN-SD-000046',46,NULL,'policy_issue','completed',4716.00,'SAR','2026-03-02 23:25:19','2026-04-21 23:25:19','2026-04-21 23:25:19'),(62,'TXN-CLM-000046',46,16,'claim_payment','pending',3692.70,'SAR','2026-04-21 23:25:20','2026-04-21 23:25:20','2026-04-21 23:25:20'),(63,'TXN-SD-000047',47,NULL,'policy_issue','completed',3312.00,'SAR','2025-05-06 22:25:20','2026-04-21 23:25:20','2026-04-21 23:25:20'),(64,'TXN-SD-000048',48,NULL,'policy_issue','completed',5021.00,'SAR','2025-10-06 22:25:20','2026-04-21 23:25:21','2026-04-21 23:25:21'),(65,'TXN-SD-000049',49,NULL,'policy_issue','completed',821.00,'SAR','2025-11-02 23:25:22','2026-04-21 23:25:22','2026-04-21 23:25:22'),(66,'TXN-CLM-000049',49,17,'claim_payment','pending',4860.90,'SAR','2026-04-21 23:25:22','2026-04-21 23:25:22','2026-04-21 23:25:22'),(67,'TXN-SD-000050',50,NULL,'policy_issue','completed',4570.00,'SAR','2026-01-16 23:25:23','2026-04-21 23:25:23','2026-04-21 23:25:23'),(68,'TXN-SD-000051',51,NULL,'policy_issue','completed',6250.00,'SAR','2025-07-03 22:25:23','2026-04-21 23:25:24','2026-04-21 23:25:24'),(69,'TXN-SD-000052',52,NULL,'policy_issue','completed',489.00,'SAR','2025-09-12 22:25:24','2026-04-21 23:25:24','2026-04-21 23:25:24'),(70,'TXN-CLM-000052',52,18,'claim_payment','pending',6498.80,'SAR','2026-04-21 23:25:25','2026-04-21 23:25:25','2026-04-21 23:25:25'),(71,'TXN-SD-000053',53,NULL,'policy_issue','completed',5237.00,'SAR','2025-10-03 22:25:25','2026-04-21 23:25:25','2026-04-21 23:25:25'),(72,'TXN-SD-000054',54,NULL,'policy_issue','completed',5701.00,'SAR','2025-08-07 22:25:25','2026-04-21 23:25:26','2026-04-21 23:25:26'),(73,'TXN-SD-000055',55,NULL,'policy_issue','completed',3134.00,'SAR','2025-11-06 23:25:26','2026-04-21 23:25:27','2026-04-21 23:25:27'),(74,'TXN-CLM-000055',55,19,'claim_payment','pending',4142.60,'SAR','2026-04-21 23:25:27','2026-04-21 23:25:27','2026-04-21 23:25:27'),(75,'TXN-SD-000056',56,NULL,'policy_issue','completed',1366.00,'SAR','2026-03-14 23:25:27','2026-04-21 23:25:28','2026-04-21 23:25:28'),(76,'TXN-SD-000057',57,NULL,'policy_issue','completed',4059.00,'SAR','2026-01-01 23:25:28','2026-04-21 23:25:28','2026-04-21 23:25:28'),(77,'TXN-SD-000058',58,NULL,'policy_issue','completed',307.00,'SAR','2026-02-16 23:25:28','2026-04-21 23:25:29','2026-04-21 23:25:29'),(78,'TXN-CLM-000058',58,20,'claim_payment','pending',2292.40,'SAR','2026-04-21 23:25:29','2026-04-21 23:25:29','2026-04-21 23:25:29'),(79,'TXN-SD-000059',59,NULL,'policy_issue','completed',2736.00,'SAR','2026-02-04 23:25:29','2026-04-21 23:25:30','2026-04-21 23:25:30'),(80,'TXN-SD-000060',60,NULL,'policy_issue','completed',1828.00,'SAR','2025-05-04 22:25:30','2026-04-21 23:25:30','2026-04-21 23:25:30'),(81,'TXN-20260422014026-174',61,NULL,'policy_issue','completed',354.38,'SAR','2026-04-21 23:40:26','2026-04-21 23:40:26','2026-04-21 23:40:26');
/*!40000 ALTER TABLE `transactions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `role` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'CLIENT',
  `branch_id` bigint unsigned DEFAULT NULL,
  `permissions` json DEFAULT NULL,
  `locale` varchar(5) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'ar',
  `theme` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'light',
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`),
  KEY `users_branch_id_index` (`branch_id`),
  CONSTRAINT `users_branch_id_foreign` FOREIGN KEY (`branch_id`) REFERENCES `branches` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'مدير النظام','admin@namaa.sa','2026-04-21 23:24:40','$2y$12$/J..9NflX1Xk0fv0Zs2nuuhiAzlq6ByVugCZKEtI.EHx0p0pQQbGe','SUPER_ADMIN',1,NULL,'ar','light',NULL,'2026-04-21 23:24:40','2026-04-21 23:24:40'),(2,'مدير فرع جدة','branch.manager@namaa.sa','2026-04-21 23:24:41','$2y$12$qQn9HzJzlAbAWOm1shkfCeHLFJFTa1fgVUCYyertDo/Lsf6AIAeIS','BRANCH_MANAGER',1,NULL,'ar','light',NULL,'2026-04-21 23:24:41','2026-04-22 00:02:01'),(3,'مكتتب رئيسي','underwriter@namaa.sa','2026-04-21 23:24:41','$2y$12$Cd7hadROSHDMYfUjX8weTemnEE4Cxp17rlqZZQCxva3nDqPEzY0Qm','UNDERWRITER',1,NULL,'ar','light',NULL,'2026-04-21 23:24:41','2026-04-21 23:24:41'),(4,'مسؤول مطالبات','claims@namaa.sa','2026-04-21 23:24:41','$2y$12$lEsIMWklYUxz5Qow/Vp3wOBbcaU2iYgNi6Y8RxVEWYrtOg/FIuLuu','CLAIMS_OFFICER',2,NULL,'ar','light',NULL,'2026-04-21 23:24:41','2026-04-21 23:24:41'),(5,'محاسب النظام','accountant@namaa.sa','2026-04-21 23:24:42','$2y$12$KnNBimeKm9NAIqQaWfWc7.O2MJmVrzZg5j1wFxgp/97vGXFlTS73q','ACCOUNTANT',1,NULL,'ar','light',NULL,'2026-04-21 23:24:42','2026-04-21 23:24:42'),(6,'وسيط الأمان - مستخدم','broker@namaa.sa','2026-04-21 23:24:42','$2y$12$sgEFWhCtmMtKy7c1ONZjIuZh0lzHaqqhmXQvVK8NnEqdz3JoHILwK','BROKER',1,'{\"broker_id\": 1}','ar','light',NULL,'2026-04-21 23:24:42','2026-04-21 23:24:42'),(7,'عميل تجريبي','client@namaa.sa','2026-04-21 23:24:42','$2y$12$Z97Nj6PCm/MUgvYY.tKue.uh7uau7U6V4Rq1nCQgq75k22iCHcb6C','CLIENT',1,'{\"client_id\": 1}','ar','light',NULL,'2026-04-21 23:24:42','2026-04-21 23:24:42');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-04-22 11:23:06
